const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const { exec, spawn } = require('child_process');
const multer = require('multer');
const AdmZip = require('adm-zip');
const axios = require('axios');

const app = express();
const PORT = 3000;

// Path Setup
const DATA_FILE = path.join(__dirname, 'data.add.json');
const BOTS_DIR = path.join(__dirname, 'bots');
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const BACKGROUNDS_DIR = path.join(__dirname, 'backgrounds');

// Pastikan folder ada
if (!fs.existsSync(BOTS_DIR)) fs.mkdirSync(BOTS_DIR, { recursive: true });
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(BACKGROUNDS_DIR)) fs.mkdirSync(BACKGROUNDS_DIR, { recursive: true });

// Middleware
app.use(bodyParser.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/backgrounds', express.static(BACKGROUNDS_DIR));

// Konfigurasi Multer untuk upload file
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        if (file.fieldname === 'botFile') {
            cb(null, UPLOAD_DIR);
        } else if (file.fieldname === 'backgroundImage') {
            cb(null, BACKGROUNDS_DIR);
        }
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ 
    storage: storage,
    limits: {
        fileSize: 50 * 1024 * 1024
    }
});

// Inisialisasi Data
function initDataFile() {
    if (!fs.existsSync(DATA_FILE)) {
        fs.writeFileSync(DATA_FILE, JSON.stringify({ 
            bots: [], 
            settings: {
                background: {
                    type: 'color',
                    value: '#0f172a'
                }
            }
        }, null, 2));
        console.log('✅ File data.add.json dibuat.');
    }
}
initDataFile();

// Helper: Download gambar dari URL
async function downloadImage(url, filename) {
    try {
        const response = await axios({
            method: 'GET',
            url: url,
            responseType: 'stream'
        });
        
        const filePath = path.join(BACKGROUNDS_DIR, filename);
        const writer = fs.createWriteStream(filePath);
        
        response.data.pipe(writer);
        
        return new Promise((resolve, reject) => {
            writer.on('finish', () => resolve(filename));
            writer.on('error', reject);
        });
    } catch (error) {
        throw new Error(`Gagal download gambar: ${error.message}`);
    }
}

// Helper: Simpan base64 image
function saveBase64Image(base64Data, filename) {
    try {
        const matches = base64Data.match(/^data:image\/([A-Za-z-+\/]+);base64,(.+)$/);
        if (!matches) {
            throw new Error('Format base64 tidak valid');
        }
        
        const extension = matches[1] === 'jpeg' ? 'jpg' : matches[1];
        const dataBuffer = Buffer.from(matches[2], 'base64');
        const filePath = path.join(BACKGROUNDS_DIR, `${filename}.${extension}`);
        
        fs.writeFileSync(filePath, dataBuffer);
        return `${filename}.${extension}`;
    } catch (error) {
        throw new Error(`Gagal simpan base64 image: ${error.message}`);
    }
}

// --- API ROUTES ---

// GET: Ambil data bot dan settings
app.get('/api/data', (req, res) => {
    try {
        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        res.json(data);
    } catch (err) {
        res.status(500).json({ error: "Gagal baca data" });
    }
});

// GET: Ambil data bot saja
app.get('/api/bots', (req, res) => {
    try {
        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        res.json(data.bots);
    } catch (err) {
        res.status(500).json({ error: "Gagal baca data" });
    }
});

// GET: Ambil background settings
app.get('/api/background', (req, res) => {
    try {
        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        res.json(data.settings?.background || { type: 'color', value: '#0f172a' });
    } catch (err) {
        res.status(500).json({ error: "Gagal baca background settings" });
    }
});

// POST: Update background
app.post('/api/background', upload.single('backgroundImage'), async (req, res) => {
    try {
        const { type, value } = req.body;
        let backgroundValue = value;
        let fileName = null;

        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        
        if (!data.settings) {
            data.settings = {};
        }

        // Hapus background image lama jika ada
        if (data.settings.background && data.settings.background.type === 'image') {
            const oldImage = data.settings.background.value;
            if (oldImage && oldImage.startsWith('bg_')) {
                const oldPath = path.join(BACKGROUNDS_DIR, oldImage);
                if (fs.existsSync(oldPath)) {
                    fs.unlinkSync(oldPath);
                }
            }
        }

        // Handle berdasarkan tipe
        switch (type) {
            case 'url':
                if (!value || !value.startsWith('http')) {
                    return res.status(400).json({ error: "URL tidak valid" });
                }
                
                fileName = `bg_${Date.now()}.jpg`;
                await downloadImage(value, fileName);
                backgroundValue = fileName;
                break;

            case 'file':
                if (!req.file) {
                    return res.status(400).json({ error: "File gambar diperlukan" });
                }
                backgroundValue = req.file.filename;
                break;

            case 'color':
                const colorRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
                if (!colorRegex.test(value)) {
                    return res.status(400).json({ error: "Format warna tidak valid" });
                }
                break;

            case 'base64':
                if (!value || !value.includes('base64')) {
                    return res.status(400).json({ error: "Data base64 tidak valid" });
                }
                
                fileName = `bg_${Date.now()}`;
                backgroundValue = saveBase64Image(value, fileName);
                break;

            default:
                return res.status(400).json({ error: "Tipe background tidak valid" });
        }

        // Update data
        data.settings.background = {
            type: type,
            value: backgroundValue,
            updatedAt: new Date().toISOString()
        };

        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        
        res.json({ 
            success: true, 
            message: "Background berhasil diupdate",
            background: data.settings.background
        });
        
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message || "Terjadi kesalahan server" });
    }
});

// POST: Reset background ke default
app.post('/api/background/reset', (req, res) => {
    try {
        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        
        if (data.settings.background && data.settings.background.type === 'image') {
            const oldImage = data.settings.background.value;
            if (oldImage && oldImage.startsWith('bg_')) {
                const oldPath = path.join(BACKGROUNDS_DIR, oldImage);
                if (fs.existsSync(oldPath)) {
                    fs.unlinkSync(oldPath);
                }
            }
        }
        
        data.settings.background = {
            type: 'color',
            value: '#0f172a',
            updatedAt: new Date().toISOString()
        };
        
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        
        res.json({ 
            success: true, 
            message: "Background berhasil direset ke default",
            background: data.settings.background
        });
        
    } catch (err) {
        res.status(500).json({ error: "Gagal reset background" });
    }
});

// GET: List background files
app.get('/api/backgrounds/list', (req, res) => {
    try {
        const files = fs.readdirSync(BACKGROUNDS_DIR)
            .filter(file => file.startsWith('bg_'))
            .map(file => ({
                name: file,
                path: `/backgrounds/${file}`,
                size: fs.statSync(path.join(BACKGROUNDS_DIR, file)).size,
                created: fs.statSync(path.join(BACKGROUNDS_DIR, file)).birthtime
            }));
        
        res.json(files);
    } catch (err) {
        res.status(500).json({ error: "Gagal membaca daftar background" });
    }
});

// POST: Tambah Bot (Hanya Nama + File)
app.post('/api/bots', upload.single('botFile'), (req, res) => {
    try {
        const { name } = req.body;
        
        if (!name) {
            if(req.file) fs.unlinkSync(req.file.path);
            return res.status(400).json({ error: "Nama Bot wajib diisi!" });
        }
        if (!req.file) {
            return res.status(400).json({ error: "File ZIP wajib diupload!" });
        }

        const botId = Date.now().toString();
        const botPath = path.join(BOTS_DIR, botId);
        fs.mkdirSync(botPath, { recursive: true });

        try {
            const zip = new AdmZip(req.file.path);
            zip.extractAllTo(botPath, true); 
            fs.unlinkSync(req.file.path);

            const items = fs.readdirSync(botPath);
            const dirs = items.filter(item => {
                const itemPath = path.join(botPath, item);
                return fs.statSync(itemPath).isDirectory();
            });

            if (dirs.length === 1) {
                const folderName = dirs[0];
                const innerPath = path.join(botPath, folderName);
                const innerItems = fs.readdirSync(innerPath);
                innerItems.forEach(innerItem => {
                    const oldPath = path.join(innerPath, innerItem);
                    const newPath = path.join(botPath, innerItem);
                    fs.renameSync(oldPath, newPath);
                });
                fs.rmdirSync(innerPath);
            }

        } catch (err) {
            console.error("Gagal unzip:", err);
            return res.status(500).json({ error: "Gagal mengekstrak file ZIP." });
        }

        const newBot = {
            id: botId,
            name: name,
            path: botPath,
            status: 'stopped',
            pid: null,
            createdAt: new Date().toLocaleString()
        };

        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        data.bots.push(newBot);
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        
        res.json({ message: "Bot berhasil ditambahkan", bot: newBot });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Terjadi kesalahan server." });
    }
});

// DELETE: Hapus Bot
app.delete('/api/bots/:id', (req, res) => {
    try {
        const { id } = req.params;
        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        const botIndex = data.bots.findIndex(b => b.id === id);

        if (botIndex === -1) return res.status(404).json({ error: "Bot tidak ditemukan" });

        if (data.bots[botIndex].pid) {
            try { process.kill(data.bots[botIndex].pid); } catch(e){}
        }

        const botPath = data.bots[botIndex].path;
        if (fs.existsSync(botPath)) {
            fs.rmSync(botPath, { recursive: true, force: true });
        }

        data.bots.splice(botIndex, 1);
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        res.json({ message: "Bot dihapus" });
    } catch (err) {
        res.status(500).json({ error: "Gagal menghapus data" });
    }
});

// --- FITUR BARU: START / STOP / RESTART ---
app.post('/api/bots/:id/start', (req, res) => {
    const { id } = req.params;
    const data = JSON.parse(fs.readFileSync(DATA_FILE));
    const botIndex = data.bots.findIndex(b => b.id === id);

    if (botIndex === -1) return res.status(404).json({ error: "Bot tidak ditemukan" });
    if (data.bots[botIndex].status === 'running') return res.status(400).json({ error: "Bot sudah berjalan!" });

    const bot = data.bots[botIndex];
    
    const child = spawn('node', ['index.js'], { 
        cwd: bot.path, 
        detached: true, 
        stdio: 'ignore' 
    });

    child.unref();

    bot.pid = child.pid;
    bot.status = 'running';
    
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
    res.json({ message: "Bot berhasil dijalankan", pid: child.pid });
});

app.post('/api/bots/:id/stop', (req, res) => {
    const { id } = req.params;
    const data = JSON.parse(fs.readFileSync(DATA_FILE));
    const botIndex = data.bots.findIndex(b => b.id === id);

    if (botIndex === -1) return res.status(404).json({ error: "Bot tidak ditemukan" });
    
    const bot = data.bots[botIndex];

    if (!bot.pid) return res.status(400).json({ error: "Bot tidak sedang berjalan." });

    try {
        process.kill(bot.pid);
        
        bot.pid = null;
        bot.status = 'stopped';
        
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        res.json({ message: "Bot berhasil dihentikan" });
    } catch (e) {
        return res.status(500).json({ error: "Gagal mematikan proses bot." });
    }
});

app.post('/api/bots/:id/restart', async (req, res) => {
    const { id } = req.params;
    
    const data = JSON.parse(fs.readFileSync(DATA_FILE));
    const botIndex = data.bots.findIndex(b => b.id === id);
    if (botIndex !== -1 && data.bots[botIndex].pid) {
        try { process.kill(data.bots[botIndex].pid); } catch(e){}
    }

    const bot = data.bots[botIndex];
    const child = spawn('node', ['index.js'], { 
        cwd: bot.path, 
        detached: true, 
        stdio: 'ignore' 
    });
    child.unref();

    bot.pid = child.pid;
    bot.status = 'running';
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));

    res.json({ message: "Bot berhasil direstart", pid: child.pid });
});

// POST: Terminal Command Runner
app.post('/api/terminal', (req, res) => {
    const { id, command } = req.body;
    const data = JSON.parse(fs.readFileSync(DATA_FILE));
    const bot = data.bots.find(b => b.id === id);

    if (!bot) return res.status(404).json({ output: "Bot tidak ditemukan" });

    exec(command, { cwd: bot.path }, (error, stdout, stderr) => {
        let output = "";
        if (stdout) output += stdout;
        if (stderr) output += `\n[ERROR]:\n${stderr}`;
        if (error) output += `\n[SYSTEM ERROR]: ${error.message}`;
        
        res.json({ output: output || "Command executed (no output)." });
    });
});

// --- FRONTEND HTML dengan WhatsApp Meta Tags ---
app.get('/', (req, res) => {
    const htmlContent = `
<!DOCTYPE html>
<html lang="id">
<head>
    <!-- WhatsApp Meta Tags untuk Link Preview -->
    <meta property="og:title" content="Panel Inori 🦀 - Bot Manager">
    <meta property="og:description" content="Dashboard untuk mengelola bot WhatsApp dengan fitur custom background">
    <meta property="og:image" content="https://files.catbox.moe/4kpvbt.jpeg">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:url" content="https://your-domain.com">
    <meta property="og:type" content="website">
    
    <!-- Twitter Cards -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Panel Inori 🦀 - Bot Manager">
    <meta name="twitter:description" content="Dashboard untuk mengelola bot WhatsApp dengan fitur custom background">
    <meta name="twitter:image" content="https://files.catbox.moe/4kpvbt.jpeg">
    
    <!-- Standard Meta Tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Panel Inori 🦀 - Bot Management Dashboard dengan fitur custom background">
    <title>Panel Inori 🦀 - Bot Manager</title>
    
    <style>
        :root {
            --bg-body: #0f172a;
            --bg-panel: #1e293b;
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
            --primary: #3b82f6;
            --danger: #ef4444;
            --success: #10b981;
            --warning: #f59e0b;
            --terminal-bg: #000000;
            --terminal-text: #00ff00;
            --border: #334155;
            --crab-color: #ff6b6b;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        body { 
            background: var(--bg-body); 
            color: var(--text-main); 
            display: flex; 
            min-height: 100vh; 
            overflow-x: hidden;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-repeat: no-repeat;
            transition: background 0.3s ease;
        }

        .content-overlay {
            background: rgba(15, 23, 42, 0.85);
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            transition: background 0.3s ease;
        }

        /* SIDEBAR */
        .sidebar {
            width: 260px;
            background: rgba(30, 41, 59, 0.95);
            border-right: 1px solid var(--border);
            padding: 20px;
            position: fixed;
            height: 100%;
            z-index: 20;
            transition: transform 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .crab-icon {
            font-size: 1.8rem;
            animation: crabWalk 3s infinite;
        }

        @keyframes crabWalk {
            0%, 100% { transform: translateX(0) rotate(0deg); }
            25% { transform: translateX(5px) rotate(-10deg); }
            50% { transform: translateX(0) rotate(0deg); }
            75% { transform: translateX(-5px) rotate(10deg); }
        }

        .main-content {
            margin-left: 260px;
            flex: 1;
            padding: 30px;
            width: calc(100% - 260px);
            transition: margin-left 0.3s ease, width 0.3s ease;
        }

        /* Header & Mobile Menu */
        .header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: 30px; 
            background: rgba(30, 41, 59, 0.9);
            padding: 15px 20px;
            border-radius: 10px;
            backdrop-filter: blur(10px);
            border: 1px solid var(--border);
        }
        .header h1 { 
            font-size: 1.8rem; 
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .menu-btn { 
            display: none; 
            font-size: 1.5rem; 
            background: rgba(59, 130, 246, 0.2); 
            border: none; 
            color: white; 
            cursor: pointer; 
            padding: 8px 12px;
            border-radius: 5px;
        }

        /* Background Control Button */
        .bg-btn {
            background: var(--primary);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9rem;
            margin-left: 10px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .bg-btn:hover {
            opacity: 0.9;
        }

        /* Grid Layout */
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }

        /* Cards */
        .card { 
            background: rgba(30, 41, 59, 0.95); 
            border: 1px solid var(--border); 
            border-radius: 8px; 
            padding: 20px; 
            position: relative;
            backdrop-filter: blur(10px);
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .bot-name { font-weight: bold; font-size: 1.2rem; }
        .status { padding: 4px 10px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; }
        .status.stopped { background: rgba(239, 68, 68, 0.2); color: var(--danger); }
        .status.running { background: rgba(16, 185, 129, 0.2); color: var(--success); }

        .info-row { font-size: 0.9rem; color: var(--text-muted); margin-bottom: 6px; }
        
        /* Action Buttons Group */
        .actions-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; margin-top: 15px; }
        .actions-secondary { display: flex; gap: 8px; margin-top: 10px; }

        .btn { 
            padding: 8px; 
            border: none; 
            border-radius: 5px; 
            cursor: pointer; 
            font-size: 0.85rem; 
            color: white; 
            font-weight: 500;
            transition: opacity 0.2s;
        }
        .btn:hover { opacity: 0.9; }
        .btn-start { background: var(--success); } 
        .btn-stop { background: var(--danger); }
        .btn-restart { background: var(--warning); }
        .btn-terminal { background: #4b5563; flex: 1; } 
        .btn-delete { background: rgba(239, 68, 68, 0.2); color: var(--danger); border: 1px solid var(--danger); flex: 1; }
        .btn-delete:hover { background: var(--danger); color: white; }
        
        .btn-add { background: var(--primary); color: white; width: 100%; margin-top: 10px; }

        /* Add Card */
        .add-card { 
            border: 2px dashed var(--border); 
            display: flex; 
            flex-direction: column; 
            align-items: center; 
            justify-content: center; 
            min-height: 180px; 
            cursor: pointer; 
            background: rgba(30, 41, 59, 0.5);
            transition: border-color 0.3s;
        }
        .add-card:hover { 
            border-color: var(--primary); 
            background: rgba(59, 130, 246, 0.1);
        }

        /* Modals */
        .modal-overlay { 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%; 
            background: rgba(0,0,0,0.9); 
            z-index: 100; 
            display: none; 
            align-items: center; 
            justify-content: center;
            backdrop-filter: blur(5px);
        }
        .modal-overlay.active { display: flex; }
        .modal { 
            background: var(--bg-panel); 
            width: 90%; 
            max-width: 500px; 
            padding: 25px; 
            border-radius: 10px; 
            border: 1px solid var(--border);
            max-height: 90vh;
            overflow-y: auto;
        }
        
        /* Tabs untuk background settings */
        .tab-buttons {
            display: flex;
            gap: 5px;
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border);
            padding-bottom: 10px;
        }
        .tab-btn {
            flex: 1;
            padding: 10px;
            background: transparent;
            border: none;
            color: var(--text-muted);
            cursor: pointer;
            border-radius: 5px;
            transition: all 0.3s;
        }
        .tab-btn.active {
            background: var(--primary);
            color: white;
        }
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
        }
        
        /* Color Picker */
        .color-picker-container {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 20px;
        }
        .color-preview {
            width: 50px;
            height: 50px;
            border-radius: 5px;
            border: 2px solid var(--border);
        }
        .color-input {
            flex: 1;
            padding: 10px;
            background: #0f172a;
            border: 1px solid var(--border);
            border-radius: 5px;
            color: white;
        }
        
        /* Preview Section */
        .preview-section {
            margin-top: 20px;
            padding: 20px;
            background: rgba(15, 23, 42, 0.5);
            border-radius: 8px;
            border: 1px solid var(--border);
        }
        .preview-title {
            font-size: 0.9rem;
            color: var(--text-muted);
            margin-bottom: 10px;
        }
        .preview-area {
            width: 100%;
            height: 150px;
            border-radius: 5px;
            border: 2px dashed var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            color: var(--text-muted);
            overflow: hidden;
            background-size: cover;
            background-position: center;
        }
        
        /* Background Grid */
        .background-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-top: 15px;
        }
        .bg-item {
            aspect-ratio: 1;
            border-radius: 5px;
            overflow: hidden;
            cursor: pointer;
            border: 2px solid transparent;
            transition: border-color 0.3s;
        }
        .bg-item:hover {
            border-color: var(--primary);
        }
        .bg-item.active {
            border-color: var(--success);
        }
        .bg-thumbnail {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        /* Forms */
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; color: var(--text-muted); font-size: 0.9rem; }
        .form-input, .form-file, .form-textarea { 
            width: 100%; 
            padding: 10px; 
            background: #0f172a; 
            border: 1px solid var(--border); 
            color: white; 
            border-radius: 5px; 
        }
        .form-file::file-selector-button { 
            background: var(--primary); 
            border: none; 
            color: white; 
            padding: 5px 10px; 
            border-radius: 4px; 
            cursor: pointer; 
            margin-right: 10px; 
        }
        .form-textarea {
            min-height: 100px;
            resize: vertical;
            font-family: monospace;
        }
        
        /* File Upload Area */
        .file-upload-area {
            border: 2px dashed var(--border);
            border-radius: 5px;
            padding: 30px;
            text-align: center;
            cursor: pointer;
            margin-bottom: 15px;
            transition: border-color 0.3s;
        }
        .file-upload-area:hover {
            border-color: var(--primary);
        }
        .file-upload-area.dragover {
            background: rgba(59, 130, 246, 0.1);
            border-color: var(--primary);
        }
        
        /* Terminal Styles */
        .terminal-box { 
            background: var(--terminal-bg); 
            color: var(--terminal-text); 
            padding: 15px; 
            border-radius: 5px; 
            height: 300px; 
            overflow-y: auto; 
            font-family: monospace; 
            font-size: 0.85rem; 
            margin-bottom: 10px; 
            white-space: pre-wrap; 
            border: 1px solid #333; 
        }
        .cmd-input-group { display: flex; gap: 10px; }
        .cmd-input { flex: 1; background: #111; border: 1px solid #333; color: white; padding: 10px; font-family: monospace; }

        /* Utilities */
        .close-btn { float: right; cursor: pointer; font-size: 1.5rem; }
        .button-group { display: flex; gap: 10px; margin-top: 20px; }
        .btn-secondary { background: #4b5563; }
        .btn-secondary:hover { background: #6b7280; }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
                width: 100%;
                padding: 15px;
            }
            .menu-btn, .bg-btn {
                display: flex;
            }
            .header h1 {
                font-size: 1.4rem;
            }
            .grid {
                grid-template-columns: 1fr;
            }
            .actions-grid {
                grid-template-columns: 1fr;
            }
            .actions-secondary {
                flex-direction: column;
            }
            .card {
                padding: 15px;
            }
            .modal {
                width: 95%;
                padding: 20px;
            }
            .background-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .color-picker-container {
                flex-direction: column;
                align-items: stretch;
            }
            .color-preview {
                width: 100%;
                height: 40px;
            }
        }

        @media (max-width: 480px) {
            .header {
                flex-direction: column;
                gap: 10px;
                align-items: stretch;
            }
            .header-buttons {
                display: flex;
                gap: 10px;
            }
            .bg-btn {
                margin-left: 0;
                flex: 1;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <!-- Background Overlay -->
    <div class="content-overlay" id="contentOverlay"></div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="crab-icon">🦀</div>
            <h2 style="color: var(--crab-color);">Panel Inori 🦀</h2>
        </div>
        <p style="font-size:0.8rem; color: #666; margin-bottom: 20px;">v3.0 dengan Background Custom</p>
        <div style="font-size: 0.9rem; color: #999; margin-bottom: 20px;">
            <p>Status: <span id="serverStatus">🟢 Online</span></p>
            <p>Bots: <span id="botCount">0</span> aktif</p>
        </div>
        <div style="margin-top: 30px;">
            <button class="btn btn-add" onclick="openBackgroundModal()">
                🎨 Custom Background
            </button>
        </div>
        <div style="margin-top: 15px;">
            <button class="btn btn-secondary" style="width:100%;" onclick="resetBackground()">
                🔄 Reset Background
            </button>
        </div>
        <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid var(--border);">
            <p style="font-size: 0.75rem; color: #666; text-align: center;">
                Panel Inori 🦀 © 2025-2026
            </p>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            <h1><span class="crab-icon">🦀</span> Dashboard Panel Inori</h1>
            <div style="display: flex; gap: 10px; align-items: center;">
                <button class="menu-btn" onclick="toggleSidebar()">☰</button>
                <button class="bg-btn" onclick="openBackgroundModal()">
                    🎨 Background
                </button>
            </div>
        </div>

        <div class="grid" id="botGrid">
            <div class="card add-card" onclick="openAddModal()">
                <div style="font-size: 3rem; margin-bottom: 10px;">+</div>
                <div>➕ Tambah Bot Baru</div>
            </div>
        </div>
    </div>

    <!-- MODAL ADD BOT -->
    <div class="modal-overlay" id="addModal">
        <div class="modal">
            <span class="close-btn" onclick="closeAddModal()">&times;</span>
            <h2 style="margin-bottom: 20px;">⚙️ Setup Bot Baru</h2>
            <form id="addForm" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Nama Bot (Label)</label>
                    <input type="text" id="name" class="form-input" placeholder="Contoh: Bot Grup WA" required>
                </div>
                <div class="form-group">
                    <label>Upload Script (.ZIP)</label>
                    <div class="file-upload-area" onclick="document.getElementById('botFile').click()" 
                         id="fileUploadArea" 
                         ondragover="handleDragOver(event)" 
                         ondragleave="handleDragLeave(event)" 
                         ondrop="handleFileDrop(event)">
                        <p style="font-size: 3rem;">📁</p>
                        <p>Klik atau drop file ZIP di sini</p>
                        <p style="font-size: 0.8rem; color: #666; margin-top: 10px;">Maksimal 50MB</p>
                    </div>
                    <input type="file" id="botFile" class="form-file" accept=".zip" hidden required>
                    <div id="fileName" style="margin-top: 10px; color: var(--primary);"></div>
                </div>
                <button type="submit" class="btn btn-add">💾 Simpan & Upload</button>
            </form>
        </div>
    </div>

    <!-- MODAL TERMINAL -->
    <div class="modal-overlay" id="terminalModal">
        <div class="modal" style="width: 90%; max-width: 700px;">
            <span class="close-btn" onclick="closeTerminal()">&times;</span>
            <h2 id="termTitle" style="margin-bottom: 15px;">💻 Terminal</h2>
            <div id="terminalOutput" class="terminal-box">Ready...<br></div>
            <form id="cmdForm" class="cmd-input-group">
                <span style="padding: 10px; color: #00ff00;">$</span>
                <input type="text" id="cmdInput" class="cmd-input" placeholder="npm install atau ls" autocomplete="off" required>
                <button type="submit" class="btn" style="background: var(--primary);">🚀 RUN</button>
            </form>
            <div style="margin-top: 10px; font-size: 0.8rem; color: #666;">
                ℹ️ Catatan: Gunakan Start/Stop untuk menjalankan bot. Terminal untuk install/log.
            </div>
        </div>
    </div>

    <!-- MODAL BACKGROUND SETTINGS -->
    <div class="modal-overlay" id="backgroundModal">
        <div class="modal" style="max-width: 600px;">
            <span class="close-btn" onclick="closeBackgroundModal()">&times;</span>
            <h2 style="margin-bottom: 20px;">🎨 Custom Background</h2>
            
            <div class="tab-buttons">
                <button class="tab-btn active" onclick="switchTab('color')">🎨 Warna</button>
                <button class="tab-btn" onclick="switchTab('url')">🔗 URL</button>
                <button class="tab-btn" onclick="switchTab('file')">📁 File</button>
                <button class="tab-btn" onclick="switchTab('base64')">📸 Base64</button>
            </div>

            <div id="colorTab" class="tab-content active">
                <div class="form-group">
                    <label>Pilih Warna Background</label>
                    <div class="color-picker-container">
                        <div class="color-preview" id="colorPreview" style="background: #0f172a;"></div>
                        <input type="text" id="colorInput" class="color-input" value="#0f172a" 
                               placeholder="#RRGGBB atau nama warna">
                    </div>
                </div>
            </div>

            <div id="urlTab" class="tab-content">
                <div class="form-group">
                    <label>URL Gambar</label>
                    <input type="url" id="urlInput" class="form-input" 
                           placeholder="https://example.com/image.jpg">
                    <small style="color: #666;">Masukkan URL gambar yang valid (JPG, PNG, GIF)</small>
                </div>
            </div>

            <div id="fileTab" class="tab-content">
                <div class="form-group">
                    <label>Upload Gambar</label>
                    <div class="file-upload-area" onclick="document.getElementById('fileInput').click()" 
                         id="imageUploadArea">
                        <p style="font-size: 3rem;">🖼️</p>
                        <p>Klik untuk upload gambar</p>
                        <p style="font-size: 0.8rem; color: #666;">JPG, PNG, GIF, WebP (Maks. 50MB)</p>
                    </div>
                    <input type="file" id="fileInput" accept="image/*" hidden>
                    <div id="imageFileName" style="margin-top: 10px; color: var(--primary);"></div>
                </div>
                
                <div class="preview-section">
                    <div class="preview-title">Background yang Tersimpan:</div>
                    <div class="background-grid" id="backgroundGrid">
                        <!-- Background items akan diisi oleh JavaScript -->
                    </div>
                </div>
            </div>

            <div id="base64Tab" class="tab-content">
                <div class="form-group">
                    <label>Base64 Image Data</label>
                    <textarea id="base64Input" class="form-textarea" 
                              placeholder="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQ..."></textarea>
                    <small style="color: #666;">Tempel data base64 gambar lengkap dengan prefix</small>
                </div>
                <button class="btn btn-secondary" onclick="captureScreenshot()" style="width:100%; margin-top:10px;">
                    📸 Capture & Convert to Base64
                </button>
            </div>

            <div class="preview-section">
                <div class="preview-title">Preview:</div>
                <div class="preview-area" id="backgroundPreview">
                    Preview akan muncul di sini
                </div>
            </div>

            <div class="button-group">
                <button class="btn btn-secondary" onclick="closeBackgroundModal()" style="flex:1;">
                    ❌ Batal
                </button>
                <button class="btn" onclick="applyBackground()" style="flex:2; background: var(--primary);">
                    💾 Terapkan Background
                </button>
            </div>
        </div>
    </div>

    <script>
        // State
        let currentBotId = null;
        let currentBackground = { type: 'color', value: '#0f172a' };
        let uploadedBackgrounds = [];

        // Load Data
        async function loadData() {
            try {
                const res = await fetch('/api/data');
                const data = await res.json();
                loadBots(data.bots);
                updateBotCount(data.bots);
                
                if (data.settings?.background) {
                    currentBackground = data.settings.background;
                    applyBackgroundToPage();
                }
            } catch (error) {
                console.error('Gagal load data:', error);
            }
        }

        async function loadBots(botsData) {
            const bots = botsData || await (await fetch('/api/bots')).json();
            const grid = document.getElementById('botGrid');
            grid.innerHTML = '<div class="card add-card" onclick="openAddModal()"><div style="font-size: 3rem; margin-bottom: 10px;">+</div><div>➕ Tambah Bot Baru</div></div>';

            bots.forEach(bot => {
                const isRunning = bot.status === 'running';
                const card = document.createElement('div');
                card.className = 'card';
                card.innerHTML = \`
                    <div class="card-header">
                        <span class="bot-name">🤖 \${bot.name}</span>
                        <span class="status \${bot.status}">\${bot.status === 'running' ? '▶️' : '⏸️'} \${bot.status}</span>
                    </div>
                    <div class="info-row">
                        <span>📁 Path:</span> <span style="font-family:monospace; font-size:0.8rem">bots/\${bot.id}</span>
                    </div>
                    <div class="info-row">
                        <span>📅 Created:</span> <span>\${bot.createdAt}</span>
                    </div>
                    
                    <div class="actions-grid">
                        <button class="btn btn-start" onclick="startBot('\${bot.id}')" \${isRunning ? 'disabled style="opacity:0.5; cursor:not-allowed"' : ''}>
                            ▶️ START
                        </button>
                        <button class="btn btn-stop" onclick="stopBot('\${bot.id}')" \${!isRunning ? 'disabled style="opacity:0.5; cursor:not-allowed"' : ''}>
                            ⏸️ STOP
                        </button>
                        <button class="btn btn-restart" onclick="restartBot('\${bot.id}')">
                            🔄 RESTART
                        </button>
                    </div>

                    <div class="actions-secondary">
                        <button class="btn btn-terminal" onclick="openTerminal('\${bot.id}', '\${bot.name}')">
                            💻 Terminal
                        </button>
                        <button class="btn btn-delete" onclick="deleteBot('\${bot.id}')">
                            🗑️ Hapus
                        </button>
                    </div>
                \`;
                grid.appendChild(card);
            });
        }

        function updateBotCount(bots) {
            const runningBots = bots ? bots.filter(b => b.status === 'running').length : 0;
            const totalBots = bots ? bots.length : 0;
            document.getElementById('botCount').textContent = \`\${runningBots}/\${totalBots}\`;
        }

        // Mobile Sidebar
        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('active');
        }

        document.addEventListener('click', (e) => {
            const sidebar = document.getElementById('sidebar');
            const menuBtn = document.querySelector('.menu-btn');
            if (window.innerWidth <= 768 && 
                !sidebar.contains(e.target) && 
                !menuBtn.contains(e.target) && 
                sidebar.classList.contains('active')) {
                sidebar.classList.remove('active');
            }
        });

        // Apply Background to Page
        function applyBackgroundToPage() {
            const body = document.body;
            const overlay = document.getElementById('contentOverlay');
            
            switch(currentBackground.type) {
                case 'color':
                    body.style.background = currentBackground.value;
                    overlay.style.background = 'rgba(15, 23, 42, 0.85)';
                    break;
                    
                case 'image':
                case 'url':
                case 'file':
                case 'base64':
                    let imageUrl = currentBackground.value;
                    
                    if (currentBackground.type === 'image' || currentBackground.type === 'file') {
                        imageUrl = '/backgrounds/' + imageUrl;
                    }
                    
                    body.style.backgroundImage = \`url("\${imageUrl}")\`;
                    body.style.backgroundSize = 'cover';
                    body.style.backgroundPosition = 'center';
                    body.style.backgroundAttachment = 'fixed';
                    overlay.style.background = 'rgba(15, 23, 42, 0.85)';
                    break;
            }
            
            updateBackgroundPreview();
        }

        // Background Functions
        async function openBackgroundModal() {
            await loadUploadedBackgrounds();
            
            if (currentBackground.type === 'color') {
                document.getElementById('colorInput').value = currentBackground.value;
                document.getElementById('colorPreview').style.background = currentBackground.value;
            } else if (currentBackground.type === 'url') {
                document.getElementById('urlInput').value = currentBackground.value;
            } else if (currentBackground.type === 'base64') {
                document.getElementById('base64Input').value = currentBackground.value || '';
            }
            
            switchTab(currentBackground.type);
            updateBackgroundPreview();
            
            document.getElementById('backgroundModal').classList.add('active');
        }

        function closeBackgroundModal() {
            document.getElementById('backgroundModal').classList.remove('active');
        }

        function switchTab(tabName) {
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active');
                if (btn.textContent.includes(tabName === 'color' ? 'Warna' : 
                                            tabName === 'url' ? 'URL' : 
                                            tabName === 'file' ? 'File' : 'Base64')) {
                    btn.classList.add('active');
                }
            });
            
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            document.getElementById(tabName + 'Tab').classList.add('active');
            
            updateBackgroundPreview();
        }

        async function loadUploadedBackgrounds() {
            try {
                const res = await fetch('/api/backgrounds/list');
                uploadedBackgrounds = await res.json();
                
                const grid = document.getElementById('backgroundGrid');
                grid.innerHTML = '';
                
                uploadedBackgrounds.forEach(bg => {
                    const isActive = currentBackground.type === 'image' && currentBackground.value === bg.name;
                    const item = document.createElement('div');
                    item.className = \`bg-item \${isActive ? 'active' : ''}\`;
                    item.innerHTML = \`
                        <img src="\${bg.path}" class="bg-thumbnail" 
                             onclick="selectBackgroundImage('\${bg.name}')">
                    \`;
                    grid.appendChild(item);
                });
            } catch (error) {
                console.error('Gagal load backgrounds:', error);
            }
        }

        function selectBackgroundImage(filename) {
            document.querySelectorAll('.bg-item').forEach(item => {
                item.classList.remove('active');
            });
            event.target.closest('.bg-item').classList.add('active');
            
            currentBackground = {
                type: 'image',
                value: filename
            };
            
            updateBackgroundPreview();
        }

        function updateBackgroundPreview() {
            const preview = document.getElementById('backgroundPreview');
            const activeTab = document.querySelector('.tab-content.active').id;
            
            switch(activeTab) {
                case 'colorTab':
                    const color = document.getElementById('colorInput').value;
                    preview.style.background = color;
                    preview.innerHTML = '<div>Warna: ' + color + '</div>';
                    break;
                    
                case 'urlTab':
                    const url = document.getElementById('urlInput').value;
                    if (url) {
                        preview.style.backgroundImage = \`url("\${url}")\`;
                        preview.style.backgroundSize = 'cover';
                        preview.innerHTML = '<div>URL Gambar</div>';
                    } else {
                        preview.style.background = '#1e293b';
                        preview.innerHTML = '<div>Masukkan URL gambar</div>';
                    }
                    break;
                    
                case 'fileTab':
                    if (currentBackground.type === 'image' && currentBackground.value) {
                        preview.style.backgroundImage = \`url("/backgrounds/\${currentBackground.value}")\`;
                        preview.style.backgroundSize = 'cover';
                        preview.innerHTML = '<div>Gambar Terpilih</div>';
                    } else {
                        preview.style.background = '#1e293b';
                        preview.innerHTML = '<div>Pilih gambar</div>';
                    }
                    break;
                    
                case 'base64Tab':
                    const base64 = document.getElementById('base64Input').value;
                    if (base64 && base64.includes('base64')) {
                        preview.style.backgroundImage = \`url("\${base64}")\`;
                        preview.style.backgroundSize = 'cover';
                        preview.innerHTML = '<div>Base64 Image</div>';
                    } else {
                        preview.style.background = '#1e293b';
                        preview.innerHTML = '<div>Masukkan data base64</div>';
                    }
                    break;
            }
        }

        document.getElementById('colorInput').addEventListener('input', function() {
            document.getElementById('colorPreview').style.background = this.value;
            updateBackgroundPreview();
        });
        
        document.getElementById('urlInput').addEventListener('input', updateBackgroundPreview);
        document.getElementById('fileInput').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                document.getElementById('imageFileName').textContent = \`File: \${file.name}\`;
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    currentBackground = {
                        type: 'file',
                        value: e.target.result
                    };
                    updateBackgroundPreview();
                };
                reader.readAsDataURL(file);
            }
        });
        
        document.getElementById('base64Input').addEventListener('input', updateBackgroundPreview);

        async function applyBackground() {
            const formData = new FormData();
            let type, value;
            
            const activeTab = document.querySelector('.tab-content.active').id;
            
            switch(activeTab) {
                case 'colorTab':
                    type = 'color';
                    value = document.getElementById('colorInput').value;
                    break;
                    
                case 'urlTab':
                    type = 'url';
                    value = document.getElementById('urlInput').value;
                    if (!value) {
                        alert('Masukkan URL gambar');
                        return;
                    }
                    break;
                    
                case 'fileTab':
                    const fileInput = document.getElementById('fileInput');
                    if (fileInput.files.length > 0) {
                        type = 'file';
                        formData.append('backgroundImage', fileInput.files[0]);
                        value = '';
                    } else if (currentBackground.type === 'image') {
                        type = 'file';
                        value = currentBackground.value;
                    } else {
                        alert('Pilih file gambar terlebih dahulu');
                        return;
                    }
                    break;
                    
                case 'base64Tab':
                    type = 'base64';
                    value = document.getElementById('base64Input').value;
                    if (!value || !value.includes('base64')) {
                        alert('Masukkan data base64 yang valid');
                        return;
                    }
                    break;
            }
            
            formData.append('type', type);
            formData.append('value', value);
            
            try {
                const res = await fetch('/api/background', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await res.json();
                
                if (data.success) {
                    currentBackground = data.background;
                    applyBackgroundToPage();
                    closeBackgroundModal();
                    alert('✅ Background berhasil diupdate!');
                } else {
                    alert('❌ Error: ' + data.error);
                }
            } catch (error) {
                alert('❌ Gagal mengupdate background');
                console.error(error);
            }
        }

        async function resetBackground() {
            if (!confirm('Reset background ke default?')) return;
            
            try {
                const res = await fetch('/api/background/reset', { method: 'POST' });
                const data = await res.json();
                
                if (data.success) {
                    currentBackground = data.background;
                    applyBackgroundToPage();
                    alert('✅ Background berhasil direset');
                }
            } catch (error) {
                alert('❌ Gagal reset background');
            }
        }

        function captureScreenshot() {
            alert('Fitur screenshot: Gunakan Print Screen atau screenshot tool lain, lalu paste ke Base64 tab');
        }

        // File Upload Drag & Drop
        function handleDragOver(e) {
            e.preventDefault();
            e.stopPropagation();
            document.getElementById('fileUploadArea').classList.add('dragover');
        }

        function handleDragLeave(e) {
            e.preventDefault();
            e.stopPropagation();
            document.getElementById('fileUploadArea').classList.remove('dragover');
        }

        function handleFileDrop(e) {
            e.preventDefault();
            e.stopPropagation();
            document.getElementById('fileUploadArea').classList.remove('dragover');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                document.getElementById('botFile').files = files;
                document.getElementById('fileName').textContent = \`File: \${files[0].name}\`;
            }
        }

        // Add Modal Functions
        const addModal = document.getElementById('addModal');
        function openAddModal() { 
            addModal.classList.add('active'); 
        }
        
        function closeAddModal() { 
            addModal.classList.remove('active'); 
            document.getElementById('addForm').reset();
            document.getElementById('fileName').textContent = '';
        }

        document.getElementById('botFile').addEventListener('change', function(e) {
            if (e.target.files.length > 0) {
                document.getElementById('fileName').textContent = \`File: \${e.target.files[0].name}\`;
            }
        });

        document.getElementById('addForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData();
            formData.append('name', document.getElementById('name').value);
            formData.append('botFile', document.getElementById('botFile').files[0]);

            const res = await fetch('/api/bots', { method: 'POST', body: formData });
            if (res.ok) {
                alert('✅ Bot Berhasil Ditambahkan!');
                closeAddModal();
                loadData();
            } else {
                const err = await res.json();
                alert('❌ Error: ' + err.error);
            }
        });

        // Bot Control Functions
        async function startBot(id) {
            const res = await fetch('/api/bots/' + id + '/start', { method: 'POST' });
            const data = await res.json();
            if(res.ok) {
                alert('✅ ' + data.message);
                loadData();
            } else {
                alert('❌ Error: ' + data.error);
            }
        }

        async function stopBot(id) {
            const res = await fetch('/api/bots/' + id + '/stop', { method: 'POST' });
            const data = await res.json();
            if(res.ok) {
                alert('✅ ' + data.message);
                loadData();
            } else {
                alert('❌ Error: ' + data.error);
            }
        }

        async function restartBot(id) {
            const res = await fetch('/api/bots/' + id + '/restart', { method: 'POST' });
            const data = await res.json();
            if(res.ok) {
                alert('✅ ' + data.message);
                loadData();
            } else {
                alert('❌ Error: ' + data.error);
            }
        }

        async function deleteBot(id) {
            if(!confirm('⚠️ Hapus bot beserta filenya?')) return;
            await fetch('/api/bots/' + id, { method: 'DELETE' });
            loadData();
        }

        // Terminal Functions
        const termModal = document.getElementById('terminalModal');
        const termOutput = document.getElementById('terminalOutput');
        
        function openTerminal(id, name) {
            currentBotId = id;
            document.getElementById('termTitle').innerText = \`💻 Terminal: \${name}\`;
            termOutput.innerHTML = \`Connected to bots/\${id}...<br>Ready.<br>\`;
            termModal.classList.add('active');
            document.getElementById('cmdInput').focus();
        }

        function closeTerminal() { 
            termModal.classList.remove('active'); 
            currentBotId = null; 
        }

        document.getElementById('cmdForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const cmd = document.getElementById('cmdInput').value;
            termOutput.innerHTML += \`<span style="color:white">root@server:$</span> \${cmd}<br>\`;
            termOutput.scrollTop = termOutput.scrollHeight;

            const res = await fetch('/api/terminal', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: currentBotId, command: cmd })
            });
            
            const data = await res.json();
            termOutput.innerHTML += data.output.replace(/\\n/g, '<br>') + '<br>';
            termOutput.scrollTop = termOutput.scrollHeight;
            document.getElementById('cmdInput').value = '';
        });

        // Initialize
        loadData();
        
        // Auto refresh every 30 seconds
        setInterval(loadData, 30000);
    </script>
</body>
</html>
    `;
    res.send(htmlContent);
});

app.listen(PORT, () => {
    console.log(`🦀 Panel Inori berjalan di http://localhost:${PORT}`);
    console.log(`🎨 Background feature aktif, folder: ${BACKGROUNDS_DIR}`);
    console.log(`📸 WhatsApp preview image: https://files.catbox.moe/4kpvbt.jpeg`);
});
