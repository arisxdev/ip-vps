const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const { exec, spawn } = require('child_process');
const multer = require('multer');
const AdmZip = require('adm-zip');
const axios = require('axios');
const ffmpeg = require('fluent-ffmpeg');

const app = express();
const PORT = 3000;

// Path Setup
const DATA_FILE = path.join(__dirname, 'data.add.json');
const BOTS_DIR = path.join(__dirname, 'bots');
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const BACKGROUNDS_DIR = path.join(__dirname, 'backgrounds');
const VIDEOS_DIR = path.join(__dirname, 'videos');

// Pastikan folder ada
if (!fs.existsSync(BOTS_DIR)) fs.mkdirSync(BOTS_DIR, { recursive: true });
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(BACKGROUNDS_DIR)) fs.mkdirSync(BACKGROUNDS_DIR, { recursive: true });
if (!fs.existsSync(VIDEOS_DIR)) fs.mkdirSync(VIDEOS_DIR, { recursive: true });

// Middleware
app.use(bodyParser.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/backgrounds', express.static(BACKGROUNDS_DIR));
app.use('/videos', express.static(VIDEOS_DIR));

// Konfigurasi Multer untuk upload file
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        if (file.fieldname === 'botFile') {
            cb(null, UPLOAD_DIR);
        } else if (file.fieldname === 'backgroundImage') {
            cb(null, BACKGROUNDS_DIR);
        } else if (file.fieldname === 'backgroundVideo') {
            cb(null, VIDEOS_DIR);
        }
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ 
    storage: storage,
    limits: {
        fileSize: 100 * 1024 * 1024 // 100MB untuk video
    }
});

// Inisialisasi Data
function initDataFile() {
    if (!fs.existsSync(DATA_FILE)) {
        fs.writeFileSync(DATA_FILE, JSON.stringify({ 
            bots: [], 
            settings: {
                background: {
                    type: 'color',
                    value: '#0f172a'
                }
            }
        }, null, 2));
        console.log('✅ File data.add.json dibuat.');
    }
}
initDataFile();

// Helper: Download file dari URL
async function downloadFile(url, filename, directory) {
    try {
        const response = await axios({
            method: 'GET',
            url: url,
            responseType: 'stream'
        });
        
        const filePath = path.join(directory, filename);
        const writer = fs.createWriteStream(filePath);
        
        response.data.pipe(writer);
        
        return new Promise((resolve, reject) => {
            writer.on('finish', () => resolve(filename));
            writer.on('error', reject);
        });
    } catch (error) {
        throw new Error(`Gagal download file: ${error.message}`);
    }
}

// Helper: Simpan base64 image
function saveBase64Image(base64Data, filename) {
    try {
        const matches = base64Data.match(/^data:image\/([A-Za-z-+\/]+);base64,(.+)$/);
        if (!matches) {
            throw new Error('Format base64 tidak valid');
        }
        
        const extension = matches[1] === 'jpeg' ? 'jpg' : matches[1];
        const dataBuffer = Buffer.from(matches[2], 'base64');
        const filePath = path.join(BACKGROUNDS_DIR, `${filename}.${extension}`);
        
        fs.writeFileSync(filePath, dataBuffer);
        return `${filename}.${extension}`;
    } catch (error) {
        throw new Error(`Gagal simpan base64 image: ${error.message}`);
    }
}

// Helper: Simpan base64 video
function saveBase64Video(base64Data, filename) {
    try {
        // Deteksi tipe video dari base64
        const videoMatch = base64Data.match(/^data:video\/([A-Za-z-+\/]+);base64,(.+)$/);
        if (!videoMatch) {
            throw new Error('Format base64 video tidak valid');
        }
        
        const extension = videoMatch[1]; // mp4, webm, etc
        const dataBuffer = Buffer.from(videoMatch[2], 'base64');
        const filePath = path.join(VIDEOS_DIR, `${filename}.${extension}`);
        
        fs.writeFileSync(filePath, dataBuffer);
        return `${filename}.${extension}`;
    } catch (error) {
        throw new Error(`Gagal simpan base64 video: ${error.message}`);
    }
}

// Helper: Generate video thumbnail
function generateVideoThumbnail(videoPath, thumbnailPath) {
    return new Promise((resolve, reject) => {
        ffmpeg(videoPath)
            .screenshots({
                timestamps: ['00:00:01'],
                filename: path.basename(thumbnailPath),
                folder: path.dirname(thumbnailPath),
                size: '320x180'
            })
            .on('end', () => resolve())
            .on('error', (err) => reject(err));
    });
}

// --- API ROUTES ---

// GET: Ambil data bot dan settings
app.get('/api/data', (req, res) => {
    try {
        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        res.json(data);
    } catch (err) {
        res.status(500).json({ error: "Gagal baca data" });
    }
});

// GET: Ambil data bot saja
app.get('/api/bots', (req, res) => {
    try {
        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        res.json(data.bots || []);
    } catch (err) {
        res.status(500).json({ error: "Gagal baca data bot" });
    }
});

// GET: Ambil background settings
app.get('/api/background', (req, res) => {
    try {
        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        res.json(data.settings?.background || { type: 'color', value: '#0f172a' });
    } catch (err) {
        res.status(500).json({ error: "Gagal baca background settings" });
    }
});

// POST: Update background
app.post('/api/background', upload.fields([
    { name: 'backgroundImage', maxCount: 1 },
    { name: 'backgroundVideo', maxCount: 1 }
]), async (req, res) => {
    try {
        const { type, value, videoOptions } = req.body;
        let backgroundValue = value;
        let fileName = null;
        let thumbnailName = null;

        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        
        if (!data.settings) {
            data.settings = {};
        }

        // Hapus background lama jika ada
        if (data.settings.background) {
            const oldBg = data.settings.background;
            
            // Hapus file lama jika tipe image
            if (oldBg.type === 'image' && oldBg.value && oldBg.value.startsWith('bg_')) {
                const oldPath = path.join(BACKGROUNDS_DIR, oldBg.value);
                if (fs.existsSync(oldPath)) {
                    fs.unlinkSync(oldPath);
                }
            }
            
            // Hapus file lama jika tipe video
            if (oldBg.type === 'video' && oldBg.value) {
                // Hapus video file
                const oldVideoPath = path.join(VIDEOS_DIR, oldBg.value);
                if (fs.existsSync(oldVideoPath)) {
                    fs.unlinkSync(oldVideoPath);
                }
                
                // Hapus thumbnail jika ada
                if (oldBg.thumbnail) {
                    const oldThumbPath = path.join(BACKGROUNDS_DIR, oldBg.thumbnail);
                    if (fs.existsSync(oldThumbPath)) {
                        fs.unlinkSync(oldThumbPath);
                    }
                }
            }
        }

        // Handle berdasarkan tipe
        switch (type) {
            case 'url':
                if (!value || !value.startsWith('http')) {
                    return res.status(400).json({ error: "URL tidak valid" });
                }
                
                // Cek jika URL adalah video
                const isVideoUrl = value.match(/\.(mp4|webm|ogg|mov|avi|mkv)$/i);
                
                if (isVideoUrl) {
                    // Handle video URL
                    fileName = `video_${Date.now()}${path.extname(value) || '.mp4'}`;
                    await downloadFile(value, fileName, VIDEOS_DIR);
                    
                    // Generate thumbnail
                    thumbnailName = `thumb_${Date.now()}.jpg`;
                    const videoPath = path.join(VIDEOS_DIR, fileName);
                    const thumbPath = path.join(BACKGROUNDS_DIR, thumbnailName);
                    
                    try {
                        await generateVideoThumbnail(videoPath, thumbPath);
                    } catch (thumbErr) {
                        console.warn('Gagal generate thumbnail:', thumbErr);
                        thumbnailName = null;
                    }
                    
                    backgroundValue = fileName;
                } else {
                    // Handle image URL
                    fileName = `bg_${Date.now()}.jpg`;
                    await downloadFile(value, fileName, BACKGROUNDS_DIR);
                    backgroundValue = fileName;
                }
                break;

            case 'file':
                if (!req.files?.backgroundImage?.[0] && !req.files?.backgroundVideo?.[0]) {
                    return res.status(400).json({ error: "File diperlukan" });
                }
                
                // Cek apakah file adalah video
                if (req.files.backgroundVideo?.[0]) {
                    const videoFile = req.files.backgroundVideo[0];
                    backgroundValue = videoFile.filename;
                    
                    // Generate thumbnail untuk video
                    thumbnailName = `thumb_${Date.now()}.jpg`;
                    const videoPath = path.join(VIDEOS_DIR, videoFile.filename);
                    const thumbPath = path.join(BACKGROUNDS_DIR, thumbnailName);
                    
                    try {
                        await generateVideoThumbnail(videoPath, thumbPath);
                    } catch (thumbErr) {
                        console.warn('Gagal generate thumbnail:', thumbErr);
                        thumbnailName = null;
                    }
                } else {
                    backgroundValue = req.files.backgroundImage[0].filename;
                }
                break;

            case 'video':
                if (!value || !value.startsWith('http')) {
                    return res.status(400).json({ error: "URL video tidak valid" });
                }
                
                fileName = `video_${Date.now()}${path.extname(value) || '.mp4'}`;
                await downloadFile(value, fileName, VIDEOS_DIR);
                
                // Generate thumbnail
                thumbnailName = `thumb_${Date.now()}.jpg`;
                const videoPath = path.join(VIDEOS_DIR, fileName);
                const thumbPath = path.join(BACKGROUNDS_DIR, thumbnailName);
                
                try {
                    await generateVideoThumbnail(videoPath, thumbPath);
                } catch (thumbErr) {
                    console.warn('Gagal generate thumbnail:', thumbErr);
                    thumbnailName = null;
                }
                
                backgroundValue = fileName;
                break;

            case 'color':
                const colorRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
                if (!colorRegex.test(value)) {
                    return res.status(400).json({ error: "Format warna tidak valid" });
                }
                break;

            case 'base64':
                if (!value || !value.includes('base64')) {
                    return res.status(400).json({ error: "Data base64 tidak valid" });
                }
                
                // Cek apakah base64 adalah image atau video
                if (value.includes('data:video/')) {
                    // Base64 video
                    fileName = `video_${Date.now()}`;
                    backgroundValue = saveBase64Video(value, fileName);
                    
                    // Generate thumbnail
                    thumbnailName = `thumb_${Date.now()}.jpg`;
                    const videoPath = path.join(VIDEOS_DIR, backgroundValue);
                    const thumbPath = path.join(BACKGROUNDS_DIR, thumbnailName);
                    
                    try {
                        await generateVideoThumbnail(videoPath, thumbPath);
                    } catch (thumbErr) {
                        console.warn('Gagal generate thumbnail:', thumbErr);
                        thumbnailName = null;
                    }
                } else {
                    // Base64 image
                    fileName = `bg_${Date.now()}`;
                    backgroundValue = saveBase64Image(value, fileName);
                }
                break;

            default:
                return res.status(400).json({ error: "Tipe background tidak valid" });
        }

        // Parse video options
        let parsedVideoOptions = {};
        try {
            parsedVideoOptions = videoOptions ? JSON.parse(videoOptions) : {};
        } catch (e) {
            console.warn('Failed to parse video options:', e);
        }

        // Update data
        data.settings.background = {
            type: type,
            value: backgroundValue,
            thumbnail: thumbnailName,
            videoOptions: parsedVideoOptions,
            updatedAt: new Date().toISOString()
        };

        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        
        res.json({ 
            success: true, 
            message: "Background berhasil diupdate",
            background: data.settings.background
        });
        
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message || "Terjadi kesalahan server" });
    }
});

// POST: Reset background ke default
app.post('/api/background/reset', (req, res) => {
    try {
        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        
        if (data.settings.background) {
            const oldBg = data.settings.background;
            
            // Hapus file lama
            if (oldBg.type === 'image' && oldBg.value && oldBg.value.startsWith('bg_')) {
                const oldPath = path.join(BACKGROUNDS_DIR, oldBg.value);
                if (fs.existsSync(oldPath)) {
                    fs.unlinkSync(oldPath);
                }
            }
            
            // Hapus video file dan thumbnail
            if (oldBg.type === 'video' && oldBg.value) {
                const oldVideoPath = path.join(VIDEOS_DIR, oldBg.value);
                if (fs.existsSync(oldVideoPath)) {
                    fs.unlinkSync(oldVideoPath);
                }
                
                if (oldBg.thumbnail) {
                    const oldThumbPath = path.join(BACKGROUNDS_DIR, oldBg.thumbnail);
                    if (fs.existsSync(oldThumbPath)) {
                        fs.unlinkSync(oldThumbPath);
                    }
                }
            }
        }
        
        data.settings.background = {
            type: 'color',
            value: '#0f172a',
            updatedAt: new Date().toISOString()
        };
        
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        
        res.json({ 
            success: true, 
            message: "Background berhasil direset ke default",
            background: data.settings.background
        });
        
    } catch (err) {
        res.status(500).json({ error: "Gagal reset background" });
    }
});

// GET: List background files
app.get('/api/backgrounds/list', (req, res) => {
    try {
        const imageFiles = fs.readdirSync(BACKGROUNDS_DIR)
            .filter(file => file.startsWith('bg_') || file.startsWith('thumb_'))
            .map(file => ({
                name: file,
                type: 'image',
                path: `/backgrounds/${file}`,
                size: fs.statSync(path.join(BACKGROUNDS_DIR, file)).size,
                created: fs.statSync(path.join(BACKGROUNDS_DIR, file)).birthtime
            }));
        
        const videoFiles = fs.readdirSync(VIDEOS_DIR)
            .filter(file => file.startsWith('video_'))
            .map(file => {
                const thumbFile = `thumb_${path.parse(file).name}.jpg`;
                const hasThumb = fs.existsSync(path.join(BACKGROUNDS_DIR, thumbFile));
                
                return {
                    name: file,
                    type: 'video',
                    path: `/videos/${file}`,
                    thumbnail: hasThumb ? `/backgrounds/${thumbFile}` : null,
                    size: fs.statSync(path.join(VIDEOS_DIR, file)).size,
                    created: fs.statSync(path.join(VIDEOS_DIR, file)).birthtime
                };
            });
        
        res.json([...imageFiles, ...videoFiles]);
    } catch (err) {
        res.status(500).json({ error: "Gagal membaca daftar background" });
    }
});

// GET: Video info
app.get('/api/video/:filename', (req, res) => {
    try {
        const filename = req.params.filename;
        const videoPath = path.join(VIDEOS_DIR, filename);
        
        if (!fs.existsSync(videoPath)) {
            return res.status(404).json({ error: "Video tidak ditemukan" });
        }
        
        const stats = fs.statSync(videoPath);
        const thumbFile = `thumb_${path.parse(filename).name}.jpg`;
        const thumbPath = path.join(BACKGROUNDS_DIR, thumbFile);
        const hasThumb = fs.existsSync(thumbPath);
        
        res.json({
            name: filename,
            path: `/videos/${filename}`,
            size: stats.size,
            created: stats.birthtime,
            thumbnail: hasThumb ? `/backgrounds/${thumbFile}` : null
        });
    } catch (err) {
        res.status(500).json({ error: "Gagal membaca info video" });
    }
});

// POST: Tambah Bot (Hanya Nama + File)
app.post('/api/bots', upload.single('botFile'), (req, res) => {
    try {
        const { name } = req.body;
        
        if (!name) {
            if(req.file) fs.unlinkSync(req.file.path);
            return res.status(400).json({ error: "Nama Bot wajib diisi!" });
        }
        if (!req.file) {
            return res.status(400).json({ error: "File ZIP wajib diupload!" });
        }

        const botId = Date.now().toString();
        const botPath = path.join(BOTS_DIR, botId);
        fs.mkdirSync(botPath, { recursive: true });

        try {
            const zip = new AdmZip(req.file.path);
            zip.extractAllTo(botPath, true); 
            fs.unlinkSync(req.file.path);

            const items = fs.readdirSync(botPath);
            const dirs = items.filter(item => {
                const itemPath = path.join(botPath, item);
                return fs.statSync(itemPath).isDirectory();
            });

            if (dirs.length === 1) {
                const folderName = dirs[0];
                const innerPath = path.join(botPath, folderName);
                const innerItems = fs.readdirSync(innerPath);
                innerItems.forEach(innerItem => {
                    const oldPath = path.join(innerPath, innerItem);
                    const newPath = path.join(botPath, innerItem);
                    fs.renameSync(oldPath, newPath);
                });
                fs.rmdirSync(innerPath);
            }

        } catch (err) {
            console.error("Gagal unzip:", err);
            return res.status(500).json({ error: "Gagal mengekstrak file ZIP." });
        }

        const newBot = {
            id: botId,
            name: name,
            path: botPath,
            status: 'stopped',
            pid: null,
            createdAt: new Date().toLocaleString()
        };

        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        if (!data.bots) data.bots = [];
        data.bots.push(newBot);
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        
        res.json({ message: "Bot berhasil ditambahkan", bot: newBot });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Terjadi kesalahan server." });
    }
});

// DELETE: Hapus Bot
app.delete('/api/bots/:id', (req, res) => {
    try {
        const { id } = req.params;
        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        
        if (!data.bots) {
            return res.status(404).json({ error: "Tidak ada data bot" });
        }
        
        const botIndex = data.bots.findIndex(b => b.id === id);

        if (botIndex === -1) {
            return res.status(404).json({ error: "Bot tidak ditemukan" });
        }

        const bot = data.bots[botIndex];

        // Stop bot jika sedang running
        if (bot.pid) {
            try { 
                process.kill(bot.pid); 
                console.log(`Stopped bot with PID: ${bot.pid}`);
            } catch(e) {
                console.log(`Bot already stopped: ${e.message}`);
            }
        }

        // Hapus folder bot
        const botPath = bot.path;
        if (fs.existsSync(botPath)) {
            fs.rmSync(botPath, { recursive: true, force: true });
            console.log(`Deleted bot folder: ${botPath}`);
        }

        // Hapus dari data
        data.bots.splice(botIndex, 1);
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        
        res.json({ 
            success: true,
            message: "Bot berhasil dihapus",
            deletedId: id 
        });
    } catch (err) {
        console.error("Error deleting bot:", err);
        res.status(500).json({ 
            success: false,
            error: "Gagal menghapus bot: " + err.message 
        });
    }
});

// --- FITUR BARU: START / STOP / RESTART ---
app.post('/api/bots/:id/start', (req, res) => {
    try {
        const { id } = req.params;
        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        
        if (!data.bots) {
            return res.status(404).json({ error: "Tidak ada data bot" });
        }
        
        const botIndex = data.bots.findIndex(b => b.id === id);

        if (botIndex === -1) return res.status(404).json({ error: "Bot tidak ditemukan" });
        if (data.bots[botIndex].status === 'running') return res.status(400).json({ error: "Bot sudah berjalan!" });

        const bot = data.bots[botIndex];
        
        const child = spawn('node', ['index.js'], { 
            cwd: bot.path, 
            detached: true, 
            stdio: 'ignore' 
        });

        child.unref();

        bot.pid = child.pid;
        bot.status = 'running';
        
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        res.json({ 
            success: true,
            message: "Bot berhasil dijalankan", 
            pid: child.pid 
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Gagal menjalankan bot" });
    }
});

app.post('/api/bots/:id/stop', (req, res) => {
    try {
        const { id } = req.params;
        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        
        if (!data.bots) {
            return res.status(404).json({ error: "Tidak ada data bot" });
        }
        
        const botIndex = data.bots.findIndex(b => b.id === id);

        if (botIndex === -1) return res.status(404).json({ error: "Bot tidak ditemukan" });
        
        const bot = data.bots[botIndex];

        if (!bot.pid) return res.status(400).json({ error: "Bot tidak sedang berjalan." });

        try {
            process.kill(bot.pid);
            
            bot.pid = null;
            bot.status = 'stopped';
            
            fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
            res.json({ 
                success: true,
                message: "Bot berhasil dihentikan" 
            });
        } catch (e) {
            console.error(e);
            return res.status(500).json({ error: "Gagal mematikan proses bot." });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Gagal menghentikan bot" });
    }
});

app.post('/api/bots/:id/restart', async (req, res) => {
    try {
        const { id } = req.params;
        
        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        
        if (!data.bots) {
            return res.status(404).json({ error: "Tidak ada data bot" });
        }
        
        const botIndex = data.bots.findIndex(b => b.id === id);
        
        if (botIndex === -1) {
            return res.status(404).json({ error: "Bot tidak ditemukan" });
        }
        
        const bot = data.bots[botIndex];
        
        // Stop bot jika sedang running
        if (bot.pid) {
            try { 
                process.kill(bot.pid); 
            } catch(e) {
                console.log(`Bot already stopped: ${e.message}`);
            }
        }

        // Start bot baru
        const child = spawn('node', ['index.js'], { 
            cwd: bot.path, 
            detached: true, 
            stdio: 'ignore' 
        });
        child.unref();

        bot.pid = child.pid;
        bot.status = 'running';
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));

        res.json({ 
            success: true,
            message: "Bot berhasil direstart", 
            pid: child.pid 
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Gagal restart bot" });
    }
});

// POST: Terminal Command Runner
app.post('/api/terminal', (req, res) => {
    try {
        const { id, command } = req.body;
        const data = JSON.parse(fs.readFileSync(DATA_FILE));
        
        if (!data.bots) {
            return res.status(404).json({ output: "Tidak ada data bot" });
        }
        
        const bot = data.bots.find(b => b.id === id);

        if (!bot) return res.status(404).json({ output: "Bot tidak ditemukan" });

        exec(command, { cwd: bot.path }, (error, stdout, stderr) => {
            let output = "";
            if (stdout) output += stdout;
            if (stderr) output += `\n[ERROR]:\n${stderr}`;
            if (error) output += `\n[SYSTEM ERROR]: ${error.message}`;
            
            res.json({ 
                success: true,
                output: output || "Command executed (no output)." 
            });
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ output: "Gagal menjalankan command" });
    }
});

// --- FRONTEND HTML dengan WhatsApp Meta Tags ---
app.get('/', (req, res) => {
    const htmlContent = `<!DOCTYPE html>
<html lang="id">
<head>
    <meta property="og:title" content="Panel Inori 🦀 - Bot Manager">
    <meta property="og:description" content="Dashboard untuk mengelola bot WhatsApp dengan fitur custom background">
    <meta property="og:image" content="https://files.catbox.moe/4kpvbt.jpeg">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:url" content="https://your-domain.com">
    <meta property="og:type" content="website">
    
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Panel Inori 🦀 - Bot Manager">
    <meta name="twitter:description" content="Dashboard untuk mengelola bot WhatsApp dengan fitur custom background">
    <meta name="twitter:image" content="https://files.catbox.moe/4kpvbt.jpeg">
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Panel Inori 🦀 - Bot Management Dashboard dengan fitur custom background">
    <title>Panel Inori 🦀 - Bot Manager</title>
    
    <style>
        :root {
            --bg-body: #0f172a;
            --bg-panel: #1e293b;
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
            --primary: #3b82f6;
            --danger: #ef4444;
            --success: #10b981;
            --warning: #f59e0b;
            --terminal-bg: #000000;
            --terminal-text: #00ff00;
            --border: #334155;
            --crab-color: #ff6b6b;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        body { 
            background: var(--bg-body); 
            color: var(--text-main); 
            display: flex; 
            min-height: 100vh; 
            overflow-x: hidden;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-repeat: no-repeat;
            transition: background 0.3s ease;
        }

        .content-overlay {
            background: rgba(15, 23, 42, 0.85);
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            transition: background 0.3s ease;
        }

        /* Video Background Container */
        .video-background-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -2;
            overflow: hidden;
            display: none;
        }

        .video-background {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            min-width: 100%;
            min-height: 100%;
            width: auto;
            height: auto;
            object-fit: cover;
        }

        .video-controls {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0, 0, 0, 0.7);
            padding: 10px 15px;
            border-radius: 20px;
            display: flex;
            gap: 10px;
            align-items: center;
            z-index: 1000;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            display: none;
        }

        .video-control-btn {
            background: transparent;
            border: none;
            color: white;
            cursor: pointer;
            font-size: 1.2rem;
            padding: 5px;
            border-radius: 50%;
            width: 35px;
            height: 35px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s;
        }

        .video-control-btn:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .volume-slider {
            width: 80px;
            cursor: pointer;
        }

        /* SIDEBAR */
        .sidebar {
            width: 260px;
            background: rgba(30, 41, 59, 0.95);
            border-right: 1px solid var(--border);
            padding: 20px;
            position: fixed;
            height: 100%;
            z-index: 20;
            transition: transform 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .crab-icon {
            font-size: 1.8rem;
            animation: crabWalk 3s infinite;
        }

        @keyframes crabWalk {
            0%, 100% { transform: translateX(0) rotate(0deg); }
            25% { transform: translateX(5px) rotate(-10deg); }
            50% { transform: translateX(0) rotate(0deg); }
            75% { transform: translateX(-5px) rotate(10deg); }
        }

        .main-content {
            margin-left: 260px;
            flex: 1;
            padding: 30px;
            width: calc(100% - 260px);
            transition: margin-left 0.3s ease, width 0.3s ease;
        }

        /* Header & Mobile Menu */
        .header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: 30px; 
            background: rgba(30, 41, 59, 0.9);
            padding: 15px 20px;
            border-radius: 10px;
            backdrop-filter: blur(10px);
            border: 1px solid var(--border);
        }
        .header h1 { 
            font-size: 1.8rem; 
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .menu-btn { 
            display: none; 
            font-size: 1.5rem; 
            background: rgba(59, 130, 246, 0.2); 
            border: none; 
            color: white; 
            cursor: pointer; 
            padding: 8px 12px;
            border-radius: 5px;
        }

        /* Background Control Button */
        .bg-btn {
            background: var(--primary);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9rem;
            margin-left: 10px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .bg-btn:hover {
            opacity: 0.9;
        }

        /* Grid Layout */
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }

        /* Cards */
        .card { 
            background: rgba(30, 41, 59, 0.95); 
            border: 1px solid var(--border); 
            border-radius: 8px; 
            padding: 20px; 
            position: relative;
            backdrop-filter: blur(10px);
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .bot-name { font-weight: bold; font-size: 1.2rem; }
        .status { padding: 4px 10px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; }
        .status.stopped { background: rgba(239, 68, 68, 0.2); color: var(--danger); }
        .status.running { background: rgba(16, 185, 129, 0.2); color: var(--success); }

        .info-row { font-size: 0.9rem; color: var(--text-muted); margin-bottom: 6px; }
        
        /* Action Buttons Group */
        .actions-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; margin-top: 15px; }
        .actions-secondary { display: flex; gap: 8px; margin-top: 10px; }

        .btn { 
            padding: 8px; 
            border: none; 
            border-radius: 5px; 
            cursor: pointer; 
            font-size: 0.85rem; 
            color: white; 
            font-weight: 500;
            transition: opacity 0.2s;
        }
        .btn:hover { opacity: 0.9; }
        .btn-start { background: var(--success); } 
        .btn-stop { background: var(--danger); }
        .btn-restart { background: var(--warning); }
        .btn-terminal { background: #4b5563; flex: 1; } 
        .btn-delete { background: rgba(239, 68, 68, 0.2); color: var(--danger); border: 1px solid var(--danger); flex: 1; }
        .btn-delete:hover { background: var(--danger); color: white; }
        
        .btn-add { background: var(--primary); color: white; width: 100%; margin-top: 10px; }

        /* Add Card */
        .add-card { 
            border: 2px dashed var(--border); 
            display: flex; 
            flex-direction: column; 
            align-items: center; 
            justify-content: center; 
            min-height: 180px; 
            cursor: pointer; 
            background: rgba(30, 41, 59, 0.5);
            transition: border-color 0.3s;
        }
        .add-card:hover { 
            border-color: var(--primary); 
            background: rgba(59, 130, 246, 0.1);
        }

        /* Modals */
        .modal-overlay { 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%; 
            background: rgba(0,0,0,0.9); 
            z-index: 100; 
            display: none; 
            align-items: center; 
            justify-content: center;
            backdrop-filter: blur(5px);
        }
        .modal-overlay.active { display: flex; }
        .modal { 
            background: var(--bg-panel); 
            width: 90%; 
            max-width: 600px; 
            padding: 25px; 
            border-radius: 10px; 
            border: 1px solid var(--border);
            max-height: 90vh;
            overflow-y: auto;
        }
        
        /* Tabs untuk background settings */
        .tab-buttons {
            display: flex;
            gap: 5px;
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border);
            padding-bottom: 10px;
            flex-wrap: wrap;
        }
        .tab-btn {
            padding: 10px;
            background: transparent;
            border: none;
            color: var(--text-muted);
            cursor: pointer;
            border-radius: 5px;
            transition: all 0.3s;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .tab-btn.active {
            background: var(--primary);
            color: white;
        }
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
        }
        
        /* Color Picker */
        .color-picker-container {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 20px;
        }
        .color-preview {
            width: 50px;
            height: 50px;
            border-radius: 5px;
            border: 2px solid var(--border);
        }
        .color-input {
            flex: 1;
            padding: 10px;
            background: #0f172a;
            border: 1px solid var(--border);
            border-radius: 5px;
            color: white;
        }
        
        /* Video Options */
        .video-options {
            background: rgba(15, 23, 42, 0.5);
            padding: 15px;
            border-radius: 8px;
            margin-top: 15px;
            border: 1px solid var(--border);
        }
        
        .option-group {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
            flex-wrap: wrap;
        }
        
        .option-label {
            width: 150px;
            font-size: 0.9rem;
            color: var(--text-muted);
        }
        
        .option-input {
            flex: 1;
            padding: 8px;
            background: #0f172a;
            border: 1px solid var(--border);
            border-radius: 5px;
            color: white;
            min-width: 200px;
        }
        
        .option-checkbox {
            width: 20px;
            height: 20px;
        }
        
        /* Preview Section */
        .preview-section {
            margin-top: 20px;
            padding: 20px;
            background: rgba(15, 23, 42, 0.5);
            border-radius: 8px;
            border: 1px solid var(--border);
        }
        .preview-title {
            font-size: 0.9rem;
            color: var(--text-muted);
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .preview-area {
            width: 100%;
            height: 200px;
            border-radius: 5px;
            border: 2px dashed var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            color: var(--text-muted);
            overflow: hidden;
            background-size: cover;
            background-position: center;
            position: relative;
        }
        
        .video-preview {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        /* Background Grid */
        .background-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-top: 15px;
        }
        .bg-item {
            aspect-ratio: 16/9;
            border-radius: 5px;
            overflow: hidden;
            cursor: pointer;
            border: 2px solid transparent;
            transition: border-color 0.3s;
            position: relative;
        }
        .bg-item:hover {
            border-color: var(--primary);
        }
        .bg-item.active {
            border-color: var(--success);
        }
        .bg-thumbnail {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .bg-type-badge {
            position: absolute;
            top: 5px;
            right: 5px;
            background: rgba(0, 0, 0, 0.7);
            color: white;
            font-size: 0.7rem;
            padding: 2px 6px;
            border-radius: 3px;
        }
        
        /* Forms */
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; color: var(--text-muted); font-size: 0.9rem; }
        .form-input, .form-file, .form-textarea { 
            width: 100%; 
            padding: 10px; 
            background: #0f172a; 
            border: 1px solid var(--border); 
            color: white; 
            border-radius: 5px; 
        }
        .form-file::file-selector-button { 
            background: var(--primary); 
            border: none; 
            color: white; 
            padding: 5px 10px; 
            border-radius: 4px; 
            cursor: pointer; 
            margin-right: 10px; 
        }
        .form-textarea {
            min-height: 120px;
            resize: vertical;
            font-family: monospace;
        }
        
        /* File Upload Area */
        .file-upload-area {
            border: 2px dashed var(--border);
            border-radius: 5px;
            padding: 30px;
            text-align: center;
            cursor: pointer;
            margin-bottom: 15px;
            transition: border-color 0.3s;
        }
        .file-upload-area:hover {
            border-color: var(--primary);
        }
        .file-upload-area.dragover {
            background: rgba(59, 130, 246, 0.1);
            border-color: var(--primary);
        }
        
        /* Terminal Styles */
        .terminal-box { 
            background: var(--terminal-bg); 
            color: var(--terminal-text); 
            padding: 15px; 
            border-radius: 5px; 
            height: 300px; 
            overflow-y: auto; 
            font-family: monospace; 
            font-size: 0.85rem; 
            margin-bottom: 10px; 
            white-space: pre-wrap; 
            border: 1px solid #333; 
        }
        .cmd-input-group { display: flex; gap: 10px; }
        .cmd-input { flex: 1; background: #111; border: 1px solid #333; color: white; padding: 10px; font-family: monospace; }

        /* Utilities */
        .close-btn { float: right; cursor: pointer; font-size: 1.5rem; }
        .button-group { display: flex; gap: 10px; margin-top: 20px; }
        .btn-secondary { background: #4b5563; }
        .btn-secondary:hover { background: #6b7280; }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
                width: 100%;
                padding: 15px;
            }
            .menu-btn, .bg-btn {
                display: flex;
            }
            .header h1 {
                font-size: 1.4rem;
            }
            .grid {
                grid-template-columns: 1fr;
            }
            .actions-grid {
                grid-template-columns: 1fr;
            }
            .actions-secondary {
                flex-direction: column;
            }
            .card {
                padding: 15px;
            }
            .modal {
                width: 95%;
                padding: 20px;
            }
            .background-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .color-picker-container {
                flex-direction: column;
                align-items: stretch;
            }
            .color-preview {
                width: 100%;
                height: 40px;
            }
            .tab-buttons {
                justify-content: center;
            }
            .tab-btn {
                font-size: 0.8rem;
                padding: 8px;
            }
            .video-controls {
                bottom: 10px;
                padding: 8px 12px;
            }
        }

        @media (max-width: 480px) {
            .header {
                flex-direction: column;
                gap: 10px;
                align-items: stretch;
            }
            .header-buttons {
                display: flex;
                gap: 10px;
            }
            .bg-btn {
                margin-left: 0;
                flex: 1;
                justify-content: center;
            }
            .tab-buttons {
                gap: 3px;
            }
            .tab-btn {
                font-size: 0.75rem;
                padding: 6px 8px;
            }
            .video-controls {
                transform: translateX(-50%) scale(0.9);
                bottom: 5px;
            }
        }
    </style>
</head>
<body>
    <!-- Video Background Container -->
    <div class="video-background-container" id="videoBackgroundContainer">
        <video class="video-background" id="backgroundVideo" loop muted playsinline>
            Your browser does not support the video tag.
        </video>
    </div>

    <!-- Video Controls -->
    <div class="video-controls" id="videoControls">
        <button class="video-control-btn" onclick="toggleVideoPlayback()" id="playPauseBtn">⏸️</button>
        <button class="video-control-btn" onclick="toggleVideoMute()" id="muteBtn">🔇</button>
        <input type="range" min="0" max="1" step="0.1" value="0.5" class="volume-slider" id="volumeSlider" oninput="changeVideoVolume(this.value)">
        <button class="video-control-btn" onclick="restartVideo()">↺</button>
    </div>

    <!-- Background Overlay -->
    <div class="content-overlay" id="contentOverlay"></div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="crab-icon">🦀</div>
            <h2 style="color: var(--crab-color);">Panel Inori 🦀</h2>
        </div>
        <p style="font-size:0.8rem; color: #666; margin-bottom: 20px;">v4.0 dengan Video Background</p>
        <div style="font-size: 0.9rem; color: #999; margin-bottom: 20px;">
            <p>Status: <span id="serverStatus">🟢 Online</span></p>
            <p>Bots: <span id="botCount">0</span> aktif</p>
        </div>
        <div style="margin-top: 30px;">
            <button class="btn btn-add" onclick="openBackgroundModal()">
                🎬 Custom Background
            </button>
        </div>
        <div style="margin-top: 15px;">
            <button class="btn btn-secondary" style="width:100%;" onclick="resetBackground()">
                🔄 Reset Background
            </button>
        </div>
        <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid var(--border);">
            <p style="font-size: 0.75rem; color: #666; text-align: center;">
                Panel Inori 🦀 © 2025-2026
            </p>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            <h1><span class="crab-icon">🦀</span> Dashboard Panel Inori</h1>
            <div style="display: flex; gap: 10px; align-items: center;">
                <button class="menu-btn" onclick="toggleSidebar()">☰</button>
                <button class="bg-btn" onclick="openBackgroundModal()">
                    🎬 Background
                </button>
            </div>
        </div>

        <div class="grid" id="botGrid">
            <div class="card add-card" onclick="openAddModal()">
                <div style="font-size: 3rem; margin-bottom: 10px;">+</div>
                <div>➕ Tambah Bot Baru</div>
            </div>
        </div>
    </div>

    <!-- MODAL ADD BOT -->
    <div class="modal-overlay" id="addModal">
        <div class="modal">
            <span class="close-btn" onclick="closeAddModal()">&times;</span>
            <h2 style="margin-bottom: 20px;">⚙️ Setup Bot Baru</h2>
            <form id="addForm" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Nama Bot (Label)</label>
                    <input type="text" id="name" class="form-input" placeholder="Contoh: Bot Grup WA" required>
                </div>
                <div class="form-group">
                    <label>Upload Script (.ZIP)</label>
                    <div class="file-upload-area" onclick="document.getElementById('botFile').click()" 
                         id="fileUploadArea" 
                         ondragover="handleDragOver(event)" 
                         ondragleave="handleDragLeave(event)" 
                         ondrop="handleFileDrop(event)">
                        <p style="font-size: 3rem;">📁</p>
                        <p>Klik atau drop file ZIP di sini</p>
                        <p style="font-size: 0.8rem; color: #666; margin-top: 10px;">Maksimal 50MB</p>
                    </div>
                    <input type="file" id="botFile" class="form-file" accept=".zip" hidden required>
                    <div id="fileName" style="margin-top: 10px; color: var(--primary);"></div>
                </div>
                <button type="submit" class="btn btn-add">💾 Simpan & Upload</button>
            </form>
        </div>
    </div>

    <!-- MODAL TERMINAL -->
    <div class="modal-overlay" id="terminalModal">
        <div class="modal" style="width: 90%; max-width: 700px;">
            <span class="close-btn" onclick="closeTerminal()">&times;</span>
            <h2 id="termTitle" style="margin-bottom: 15px;">💻 Terminal</h2>
            <div id="terminalOutput" class="terminal-box">Ready...<br></div>
            <form id="cmdForm" class="cmd-input-group">
                <span style="padding: 10px; color: #00ff00;">$</span>
                <input type="text" id="cmdInput" class="cmd-input" placeholder="npm install atau ls" autocomplete="off" required>
                <button type="submit" class="btn" style="background: var(--primary);">🚀 RUN</button>
            </form>
            <div style="margin-top: 10px; font-size: 0.8rem; color: #666;">
                ℹ️ Catatan: Gunakan Start/Stop untuk menjalankan bot. Terminal untuk install/log.
            </div>
        </div>
    </div>

    <!-- MODAL BACKGROUND SETTINGS -->
    <div class="modal-overlay" id="backgroundModal">
        <div class="modal" style="max-width: 700px;">
            <span class="close-btn" onclick="closeBackgroundModal()">&times;</span>
            <h2 style="margin-bottom: 20px;">🎬 Custom Background</h2>
            
            <div class="tab-buttons">
                <button class="tab-btn active" onclick="switchTab('color')">🎨 Warna</button>
                <button class="tab-btn" onclick="switchTab('url')">🔗 URL</button>
                <button class="tab-btn" onclick="switchTab('file')">📁 File</button>
                <button class="tab-btn" onclick="switchTab('video')">🎬 Video</button>
                <button class="tab-btn" onclick="switchTab('base64')">📸 Base64</button>
            </div>

            <!-- Color Tab -->
            <div id="colorTab" class="tab-content active">
                <div class="form-group">
                    <label>Pilih Warna Background</label>
                    <div class="color-picker-container">
                        <div class="color-preview" id="colorPreview" style="background: #0f172a;"></div>
                        <input type="text" id="colorInput" class="color-input" value="#0f172a" 
                               placeholder="#RRGGBB atau nama warna">
                    </div>
                </div>
            </div>

            <!-- URL Tab -->
            <div id="urlTab" class="tab-content">
                <div class="form-group">
                    <label>URL Gambar/Video</label>
                    <input type="url" id="urlInput" class="form-input" 
                           placeholder="https://example.com/image.jpg atau video.mp4">
                    <small style="color: #666;">Masukkan URL gambar (JPG, PNG, GIF) atau video (MP4, WebM)</small>
                </div>
            </div>

            <!-- File Tab -->
            <div id="fileTab" class="tab-content">
                <div class="form-group">
                    <label>Upload Gambar/Video</label>
                    <div class="file-upload-area" onclick="document.getElementById('fileInput').click()" 
                         id="imageUploadArea">
                        <p style="font-size: 3rem;">📁</p>
                        <p>Klik untuk upload gambar atau video</p>
                        <p style="font-size: 0.8rem; color: #666;">Gambar: JPG, PNG, GIF | Video: MP4, WebM, MOV (Maks. 100MB)</p>
                    </div>
                    <input type="file" id="fileInput" accept="image/*,video/*" hidden>
                    <div id="imageFileName" style="margin-top: 10px; color: var(--primary);"></div>
                </div>
                
                <div class="preview-section">
                    <div class="preview-title">Background yang Tersimpan:</div>
                    <div class="background-grid" id="backgroundGrid">
                        <!-- Background items akan diisi oleh JavaScript -->
                    </div>
                </div>
            </div>

            <!-- Video Tab -->
            <div id="videoTab" class="tab-content">
                <div class="form-group">
                    <label>URL Video</label>
                    <input type="url" id="videoUrlInput" class="form-input" 
                           placeholder="https://example.com/video.mp4">
                    <small style="color: #666;">Masukkan URL video (MP4, WebM, OGG, MOV, AVI, MKV)</small>
                </div>
                
                <div class="video-options">
                    <h4 style="margin-bottom: 15px; color: var(--text-muted);">🎬 Video Options</h4>
                    
                    <div class="option-group">
                        <div class="option-label">Auto Play:</div>
                        <input type="checkbox" id="autoPlayOption" class="option-checkbox" checked>
                    </div>
                    
                    <div class="option-group">
                        <div class="option-label">Loop:</div>
                        <input type="checkbox" id="loopOption" class="option-checkbox" checked>
                    </div>
                    
                    <div class="option-group">
                        <div class="option-label">Muted:</div>
                        <input type="checkbox" id="mutedOption" class="option-checkbox" checked>
                    </div>
                    
                    <div class="option-group">
                        <div class="option-label">Volume:</div>
                        <input type="range" min="0" max="1" step="0.1" value="0.5" 
                               id="volumeOption" class="option-input" style="flex: none; width: 200px;">
                        <span id="volumeValue">50%</span>
                    </div>
                    
                    <div class="option-group">
                        <div class="option-label">Playback Rate:</div>
                        <select id="playbackRateOption" class="option-input" style="flex: none; width: 200px;">
                            <option value="0.5">0.5x (Slow)</option>
                            <option value="0.75">0.75x</option>
                            <option value="1" selected>1x (Normal)</option>
                            <option value="1.25">1.25x</option>
                            <option value="1.5">1.5x</option>
                            <option value="2">2x (Fast)</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Base64 Tab -->
            <div id="base64Tab" class="tab-content">
                <div class="form-group">
                    <label>Base64 Image/Video Data</label>
                    <textarea id="base64Input" class="form-textarea" 
                              placeholder="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQ..."></textarea>
                    <small style="color: #666;">Tempel data base64 gambar atau video lengkap dengan prefix</small>
                </div>
                <button class="btn btn-secondary" onclick="captureScreenshot()" style="width:100%; margin-top:10px;">
                    📸 Capture & Convert to Base64
                </button>
            </div>

            <!-- Video Options for All Tabs -->
            <div class="video-options" id="videoOptionsSection" style="display: none;">
                <h4 style="margin-bottom: 15px; color: var(--text-muted);">🎬 Video Options</h4>
                
                <div class="option-group">
                    <div class="option-label">Auto Play:</div>
                    <input type="checkbox" id="autoPlayOptionGlobal" class="option-checkbox" checked>
                </div>
                
                <div class="option-group">
                    <div class="option-label">Loop:</div>
                    <input type="checkbox" id="loopOptionGlobal" class="option-checkbox" checked>
                </div>
                
                <div class="option-group">
                    <div class="option-label">Muted:</div>
                    <input type="checkbox" id="mutedOptionGlobal" class="option-checkbox" checked>
                </div>
            </div>

            <!-- Preview Section -->
            <div class="preview-section">
                <div class="preview-title">
                    <span>Preview:</span>
                    <button class="btn btn-secondary" onclick="updateBackgroundPreview()" style="padding: 5px 10px; font-size: 0.8rem;">
                        🔄 Refresh Preview
                    </button>
                </div>
                <div class="preview-area" id="backgroundPreview">
                    Preview akan muncul di sini
                </div>
            </div>

            <div class="button-group">
                <button class="btn btn-secondary" onclick="closeBackgroundModal()" style="flex:1;">
                    ❌ Batal
                </button>
                <button class="btn" onclick="applyBackground()" style="flex:2; background: var(--primary);">
                    💾 Terapkan Background
                </button>
            </div>
        </div>
    </div>

    <script>
        // State
        let currentBotId = null;
        let currentBackground = { type: 'color', value: '#0f172a' };
        let uploadedBackgrounds = [];
        let videoElement = null;
        let videoControlsVisible = false;

        // Helper function untuk escape HTML
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Helper function untuk escape quotes
        function escapeQuotes(text) {
            return text.replace(/'/g, "\\'").replace(/"/g, '\\"');
        }

        // Load Data
        async function loadData() {
            try {
                const res = await fetch('/api/data');
                const data = await res.json();
                loadBots(data.bots);
                updateBotCount(data.bots);
                
                if (data.settings?.background) {
                    currentBackground = data.settings.background;
                    applyBackgroundToPage();
                }
            } catch (error) {
                console.error('Gagal load data:', error);
            }
        }

        // Load Bots dengan event delegation
        async function loadBots(botsData) {
            try {
                const bots = botsData || await (await fetch('/api/bots')).json();
                const grid = document.getElementById('botGrid');
                
                // Clear grid dan tambah add card
                grid.innerHTML = '<div class="card add-card" onclick="openAddModal()"><div style="font-size: 3rem; margin-bottom: 10px;">+</div><div>➕ Tambah Bot Baru</div></div>';

                // Tambah setiap bot
                bots.forEach(bot => {
                    const isRunning = bot.status === 'running';
                    const card = document.createElement('div');
                    card.className = 'card';
                    card.setAttribute('data-bot-id', bot.id);
                    
                    // Escape nama bot untuk HTML
                    const safeName = escapeHtml(bot.name);
                    
                    card.innerHTML = \`
                        <div class="card-header">
                            <span class="bot-name">🤖 \${safeName}</span>
                            <span class="status \${bot.status}">\${bot.status === 'running' ? '▶️' : '⏸️'} \${bot.status}</span>
                        </div>
                        <div class="info-row">
                            <span>📁 Path:</span> <span style="font-family:monospace; font-size:0.8rem">bots/\${bot.id}</span>
                        </div>
                        <div class="info-row">
                            <span>📅 Created:</span> <span>\${bot.createdAt}</span>
                        </div>
                        
                        <div class="actions-grid">
                            <button class="btn btn-start" data-action="start" data-botid="\${bot.id}" \${isRunning ? 'disabled style="opacity:0.5; cursor:not-allowed"' : ''}>
                                ▶️ START
                            </button>
                            <button class="btn btn-stop" data-action="stop" data-botid="\${bot.id}" \${!isRunning ? 'disabled style="opacity:0.5; cursor:not-allowed"' : ''}>
                                ⏸️ STOP
                            </button>
                            <button class="btn btn-restart" data-action="restart" data-botid="\${bot.id}">
                                🔄 RESTART
                            </button>
                        </div>

                        <div class="actions-secondary">
                            <button class="btn btn-terminal" data-action="terminal" data-botid="\${bot.id}" data-botname="\${escapeQuotes(safeName)}">
                                💻 Terminal
                            </button>
                            <button class="btn btn-delete" data-action="delete" data-botid="\${bot.id}">
                                🗑️ Hapus
                            </button>
                        </div>
                    \`;
                    grid.appendChild(card);
                });
                
                updateBotCount(bots);
            } catch (error) {
                console.error('Error loading bots:', error);
                const grid = document.getElementById('botGrid');
                grid.innerHTML = '<div class="card add-card" onclick="openAddModal()"><div style="font-size: 3rem; margin-bottom: 10px;">+</div><div>➕ Tambah Bot Baru</div></div>';
                grid.innerHTML += '<div class="card"><div style="color: var(--danger); text-align: center;">Gagal memuat data bot</div></div>';
            }
        }

        function updateBotCount(bots) {
            const runningBots = bots ? bots.filter(b => b.status === 'running').length : 0;
            const totalBots = bots ? bots.length : 0;
            document.getElementById('botCount').textContent = \`\${runningBots}/\${totalBots}\`;
        }

        // Event delegation untuk semua button bot
        document.addEventListener('click', function(e) {
            const target = e.target;
            
            // Handle button dengan data-action
            if (target.closest('[data-action]')) {
                const button = target.closest('[data-action]');
                const action = button.getAttribute('data-action');
                const botId = button.getAttribute('data-botid');
                const botName = button.getAttribute('data-botname');
                
                if (!botId) return;
                
                switch(action) {
                    case 'start':
                        startBot(botId);
                        break;
                    case 'stop':
                        stopBot(botId);
                        break;
                    case 'restart':
                        restartBot(botId);
                        break;
                    case 'terminal':
                        openTerminal(botId, botName || '');
                        break;
                    case 'delete':
                        deleteBot(botId);
                        break;
                }
            }
        });

        // Mobile Sidebar
        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('active');
        }

        document.addEventListener('click', (e) => {
            const sidebar = document.getElementById('sidebar');
            const menuBtn = document.querySelector('.menu-btn');
            if (window.innerWidth <= 768 && 
                !sidebar.contains(e.target) && 
                !menuBtn.contains(e.target) && 
                sidebar.classList.contains('active')) {
                sidebar.classList.remove('active');
            }
        });

        // Apply Background to Page
        function applyBackgroundToPage() {
            const body = document.body;
            const overlay = document.getElementById('contentOverlay');
            const videoContainer = document.getElementById('videoBackgroundContainer');
            const videoControls = document.getElementById('videoControls');
            
            // Reset semua background
            body.style.backgroundImage = '';
            body.style.backgroundColor = '';
            videoContainer.style.display = 'none';
            videoControls.style.display = 'none';
            
            if (videoElement) {
                videoElement.pause();
                videoElement.src = '';
            }
            
            switch(currentBackground.type) {
                case 'color':
                    body.style.backgroundColor = currentBackground.value;
                    overlay.style.background = 'rgba(15, 23, 42, 0.85)';
                    break;
                    
                case 'image':
                case 'url':
                case 'file':
                case 'base64':
                    let sourceUrl = currentBackground.value;
                    
                    // Cek jika ini adalah video
                    const isVideo = currentBackground.type === 'video' || 
                                   (currentBackground.type === 'url' && sourceUrl.match(/\\.(mp4|webm|ogg|mov|avi|mkv)$/i)) ||
                                   (currentBackground.type === 'file' && sourceUrl.match(/\\.(mp4|webm|ogg|mov|avi|mkv)$/i));
                    
                    if (isVideo) {
                        // Setup video background
                        videoContainer.style.display = 'block';
                        
                        if (!videoElement) {
                            videoElement = document.getElementById('backgroundVideo');
                        }
                        
                        // Bangun URL video
                        if (currentBackground.type === 'video' || currentBackground.type === 'file') {
                            sourceUrl = '/videos/' + sourceUrl;
                        }
                        
                        videoElement.src = sourceUrl;
                        
                        // Apply video options
                        const options = currentBackground.videoOptions || {};
                        videoElement.autoplay = options.autoplay !== false;
                        videoElement.loop = options.loop !== false;
                        videoElement.muted = options.muted !== false;
                        videoElement.volume = options.volume || 0.5;
                        videoElement.playbackRate = options.playbackRate || 1;
                        
                        // Setup event listeners
                        videoElement.onloadeddata = function() {
                            videoElement.play().catch(e => console.log('Autoplay prevented:', e));
                        };
                        
                        // Tampilkan controls jika video tidak muted
                        if (!videoElement.muted) {
                            videoControls.style.display = 'flex';
                            videoControlsVisible = true;
                        }
                        
                        overlay.style.background = 'rgba(15, 23, 42, 0.7)';
                    } else {
                        // Setup image background
                        if (currentBackground.type === 'image' || currentBackground.type === 'file') {
                            sourceUrl = '/backgrounds/' + sourceUrl;
                        }
                        
                        body.style.backgroundImage = \`url("\${sourceUrl}")\`;
                        body.style.backgroundSize = 'cover';
                        body.style.backgroundPosition = 'center';
                        body.style.backgroundAttachment = 'fixed';
                        overlay.style.background = 'rgba(15, 23, 42, 0.85)';
                    }
                    break;
            }
        }

        // Video Controls Functions
        function toggleVideoPlayback() {
            if (videoElement) {
                if (videoElement.paused) {
                    videoElement.play();
                    document.getElementById('playPauseBtn').textContent = '⏸️';
                } else {
                    videoElement.pause();
                    document.getElementById('playPauseBtn').textContent = '▶️';
                }
            }
        }

        function toggleVideoMute() {
            if (videoElement) {
                videoElement.muted = !videoElement.muted;
                document.getElementById('muteBtn').textContent = videoElement.muted ? '🔇' : '🔊';
                
                // Tampilkan/sembunyikan controls berdasarkan mute status
                const videoControls = document.getElementById('videoControls');
                if (videoElement.muted) {
                    videoControls.style.display = 'none';
                    videoControlsVisible = false;
                } else {
                    videoControls.style.display = 'flex';
                    videoControlsVisible = true;
                }
            }
        }

        function changeVideoVolume(value) {
            if (videoElement) {
                videoElement.volume = parseFloat(value);
                document.getElementById('volumeSlider').value = value;
                
                // Update mute button jika volume 0
                if (videoElement.volume === 0) {
                    videoElement.muted = true;
                    document.getElementById('muteBtn').textContent = '🔇';
                } else if (videoElement.muted) {
                    videoElement.muted = false;
                    document.getElementById('muteBtn').textContent = '🔊';
                }
            }
        }

        function restartVideo() {
            if (videoElement) {
                videoElement.currentTime = 0;
                videoElement.play();
                document.getElementById('playPauseBtn').textContent = '⏸️';
            }
        }

        // Show/hide video controls on hover
        document.addEventListener('mousemove', (e) => {
            if (videoElement && videoControlsVisible) {
                const videoControls = document.getElementById('videoControls');
                const isNearBottom = e.clientY > window.innerHeight - 100;
                
                if (isNearBottom) {
                    videoControls.style.opacity = '1';
                    videoControls.style.pointerEvents = 'auto';
                } else {
                    videoControls.style.opacity = '0';
                    videoControls.style.pointerEvents = 'none';
                }
            }
        });

        // Background Functions
        async function openBackgroundModal() {
            await loadUploadedBackgrounds();
            
            // Set nilai berdasarkan current background
            switch(currentBackground.type) {
                case 'color':
                    document.getElementById('colorInput').value = currentBackground.value;
                    document.getElementById('colorPreview').style.background = currentBackground.value;
                    break;
                case 'url':
                    document.getElementById('urlInput').value = currentBackground.value;
                    break;
                case 'video':
                    document.getElementById('videoUrlInput').value = currentBackground.value;
                    // Set video options
                    const options = currentBackground.videoOptions || {};
                    document.getElementById('autoPlayOption').checked = options.autoplay !== false;
                    document.getElementById('loopOption').checked = options.loop !== false;
                    document.getElementById('mutedOption').checked = options.muted !== false;
                    document.getElementById('volumeOption').value = options.volume || 0.5;
                    document.getElementById('volumeValue').textContent = \`\${(options.volume || 0.5) * 100}%\`;
                    document.getElementById('playbackRateOption').value = options.playbackRate || 1;
                    break;
                case 'base64':
                    document.getElementById('base64Input').value = currentBackground.value || '';
                    break;
            }
            
            switchTab(currentBackground.type);
            updateBackgroundPreview();
            
            document.getElementById('backgroundModal').classList.add('active');
        }

        function closeBackgroundModal() {
            document.getElementById('backgroundModal').classList.remove('active');
        }

        function switchTab(tabName) {
            // Update tab buttons
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Aktifkan tab yang dipilih
            document.getElementById(tabName + 'Tab').classList.add('active');
            
            // Aktifkan tab button yang sesuai
            document.querySelectorAll('.tab-btn').forEach(btn => {
                if (btn.textContent.includes(tabName === 'color' ? 'Warna' : 
                    tabName === 'url' ? 'URL' : 
                    tabName === 'file' ? 'File' : 
                    tabName === 'video' ? 'Video' : 'Base64')) {
                    btn.classList.add('active');
                }
            });
            
            // Tampilkan/sembunyikan video options section
            const videoOptionsSection = document.getElementById('videoOptionsSection');
            if (tabName === 'url' || tabName === 'file' || tabName === 'base64') {
                videoOptionsSection.style.display = 'block';
            } else {
                videoOptionsSection.style.display = 'none';
            }
            
            updateBackgroundPreview();
        }

        async function loadUploadedBackgrounds() {
            try {
                const res = await fetch('/api/backgrounds/list');
                uploadedBackgrounds = await res.json();
                
                const grid = document.getElementById('backgroundGrid');
                grid.innerHTML = '';
                
                uploadedBackgrounds.forEach(bg => {
                    const isActive = currentBackground.value === bg.name;
                    const isVideo = bg.type === 'video';
                    const thumbnailUrl = bg.thumbnail || bg.path;
                    
                    const item = document.createElement('div');
                    item.className = \`bg-item \${isActive ? 'active' : ''}\`;
                    item.innerHTML = \`
                        <img src="\${thumbnailUrl}" class="bg-thumbnail" 
                             onclick="selectBackgroundFile('\${bg.name}', '\${bg.type}')">
                        <div class="bg-type-badge">\${isVideo ? '🎬' : '🖼️'}</div>
                    \`;
                    grid.appendChild(item);
                });
            } catch (error) {
                console.error('Gagal load backgrounds:', error);
            }
        }

        function selectBackgroundFile(filename, type) {
            document.querySelectorAll('.bg-item').forEach(item => {
                item.classList.remove('active');
            });
            event.target.closest('.bg-item').classList.add('active');
            
            currentBackground = {
                type: type,
                value: filename
            };
            
            updateBackgroundPreview();
        }

        function updateBackgroundPreview() {
            const preview = document.getElementById('backgroundPreview');
            const activeTab = document.querySelector('.tab-content.active').id;
            
            preview.innerHTML = '';
            
            switch(activeTab) {
                case 'colorTab':
                    const color = document.getElementById('colorInput').value;
                    preview.style.background = color;
                    preview.style.backgroundImage = 'none';
                    preview.innerHTML = '<div>Warna: ' + color + '</div>';
                    break;
                    
                case 'urlTab':
                    const url = document.getElementById('urlInput').value;
                    if (url) {
                        const isVideo = url.match(/\\.(mp4|webm|ogg|mov|avi|mkv)$/i);
                        
                        if (isVideo) {
                            // Video preview
                            const video = document.createElement('video');
                            video.src = url;
                            video.className = 'video-preview';
                            video.muted = true;
                            video.loop = true;
                            video.autoplay = true;
                            video.controls = false;
                            preview.appendChild(video);
                            preview.style.backgroundImage = 'none';
                        } else {
                            // Image preview
                            preview.style.backgroundImage = \`url("\${url}")\`;
                            preview.style.backgroundSize = 'cover';
                            preview.innerHTML = '<div>URL Gambar</div>';
                        }
                    } else {
                        preview.style.background = '#1e293b';
                        preview.style.backgroundImage = 'none';
                        preview.innerHTML = '<div>Masukkan URL gambar/video</div>';
                    }
                    break;
                    
                case 'fileTab':
                    if (currentBackground.type && currentBackground.value) {
                        const isVideo = currentBackground.value.match(/\\.(mp4|webm|ogg|mov|avi|mkv)$/i);
                        
                        if (isVideo) {
                            // Video preview
                            const video = document.createElement('video');
                            video.src = '/videos/' + currentBackground.value;
                            video.className = 'video-preview';
                            video.muted = true;
                            video.loop = true;
                            video.autoplay = true;
                            video.controls = false;
                            preview.appendChild(video);
                            preview.style.backgroundImage = 'none';
                        } else {
                            // Image preview
                            preview.style.backgroundImage = \`url("/backgrounds/\${currentBackground.value}")\`;
                            preview.style.backgroundSize = 'cover';
                            preview.innerHTML = '<div>Gambar Terpilih</div>';
                        }
                    } else {
                        preview.style.background = '#1e293b';
                        preview.style.backgroundImage = 'none';
                        preview.innerHTML = '<div>Pilih file</div>';
                    }
                    break;
                    
                case 'videoTab':
                    const videoUrl = document.getElementById('videoUrlInput').value;
                    if (videoUrl) {
                        const video = document.createElement('video');
                        video.src = videoUrl;
                        video.className = 'video-preview';
                        video.muted = true;
                        video.loop = true;
                        video.autoplay = true;
                        video.controls = false;
                        preview.appendChild(video);
                        preview.style.backgroundImage = 'none';
                    } else {
                        preview.style.background = '#1e293b';
                        preview.style.backgroundImage = 'none';
                        preview.innerHTML = '<div>Masukkan URL video</div>';
                    }
                    break;
                    
                case 'base64Tab':
                    const base64 = document.getElementById('base64Input').value;
                    if (base64 && base64.includes('base64')) {
                        const isVideo = base64.includes('data:video/');
                        
                        if (isVideo) {
                            // Video preview
                            const video = document.createElement('video');
                            video.src = base64;
                            video.className = 'video-preview';
                            video.muted = true;
                            video.loop = true;
                            video.autoplay = true;
                            video.controls = false;
                            preview.appendChild(video);
                            preview.style.backgroundImage = 'none';
                        } else {
                            // Image preview
                            preview.style.backgroundImage = \`url("\${base64}")\`;
                            preview.style.backgroundSize = 'cover';
                            preview.innerHTML = '<div>Base64 Image</div>';
                        }
                    } else {
                        preview.style.background = '#1e293b';
                        preview.style.backgroundImage = 'none';
                        preview.innerHTML = '<div>Masukkan data base64</div>';
                    }
                    break;
            }
        }

        // Event listeners untuk input changes
        document.getElementById('colorInput').addEventListener('input', function() {
            document.getElementById('colorPreview').style.background = this.value;
            updateBackgroundPreview();
        });
        
        document.getElementById('urlInput').addEventListener('input', updateBackgroundPreview);
        document.getElementById('videoUrlInput').addEventListener('input', updateBackgroundPreview);
        
        document.getElementById('fileInput').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                document.getElementById('imageFileName').textContent = \`File: \${file.name}\`;
                
                const isVideo = file.type.startsWith('video/');
                currentBackground = {
                    type: 'file',
                    value: file.name
                };
                
                updateBackgroundPreview();
            }
        });
        
        document.getElementById('base64Input').addEventListener('input', updateBackgroundPreview);
        
        // Video options listeners
        document.getElementById('volumeOption').addEventListener('input', function(e) {
            document.getElementById('volumeValue').textContent = \`\${Math.round(e.target.value * 100)}%\`;
        });
        
        document.getElementById('autoPlayOptionGlobal').addEventListener('change', updateBackgroundPreview);
        document.getElementById('loopOptionGlobal').addEventListener('change', updateBackgroundPreview);
        document.getElementById('mutedOptionGlobal').addEventListener('change', updateBackgroundPreview);

        async function applyBackground() {
            const formData = new FormData();
            let type, value;
            let videoOptions = {};
            
            const activeTab = document.querySelector('.tab-content.active').id;
            
            switch(activeTab) {
                case 'colorTab':
                    type = 'color';
                    value = document.getElementById('colorInput').value;
                    break;
                    
                case 'urlTab':
                    const urlValue = document.getElementById('urlInput').value;
                    if (!urlValue) {
                        alert('Masukkan URL gambar/video');
                        return;
                    }
                    
                    // Tentukan apakah ini gambar atau video
                    const isVideoUrl = urlValue.match(/\\.(mp4|webm|ogg|mov|avi|mkv)$/i);
                    type = isVideoUrl ? 'video' : 'url';
                    value = urlValue;
                    
                    // Add video options jika video
                    if (isVideoUrl) {
                        videoOptions = {
                            autoplay: document.getElementById('autoPlayOptionGlobal').checked,
                            loop: document.getElementById('loopOptionGlobal').checked,
                            muted: document.getElementById('mutedOptionGlobal').checked
                        };
                    }
                    break;
                    
                case 'fileTab':
                    const fileInput = document.getElementById('fileInput');
                    if (fileInput.files.length > 0) {
                        type = 'file';
                        const file = fileInput.files[0];
                        const isVideo = file.type.startsWith('video/');
                        
                        if (isVideo) {
                            formData.append('backgroundVideo', file);
                            videoOptions = {
                                autoplay: document.getElementById('autoPlayOptionGlobal').checked,
                                loop: document.getElementById('loopOptionGlobal').checked,
                                muted: document.getElementById('mutedOptionGlobal').checked
                            };
                        } else {
                            formData.append('backgroundImage', file);
                        }
                        value = '';
                    } else if (currentBackground.type === 'file' || currentBackground.type === 'image') {
                        type = currentBackground.type;
                        value = currentBackground.value;
                        
                        // Add video options jika video
                        if (currentBackground.value.match(/\\.(mp4|webm|ogg|mov|avi|mkv)$/i)) {
                            videoOptions = {
                                autoplay: document.getElementById('autoPlayOptionGlobal').checked,
                                loop: document.getElementById('loopOptionGlobal').checked,
                                muted: document.getElementById('mutedOptionGlobal').checked
                            };
                        }
                    } else {
                        alert('Pilih file gambar/video terlebih dahulu');
                        return;
                    }
                    break;
                    
                case 'videoTab':
                    type = 'video';
                    value = document.getElementById('videoUrlInput').value;
                    if (!value) {
                        alert('Masukkan URL video');
                        return;
                    }
                    
                    videoOptions = {
                        autoplay: document.getElementById('autoPlayOption').checked,
                        loop: document.getElementById('loopOption').checked,
                        muted: document.getElementById('mutedOption').checked,
                        volume: parseFloat(document.getElementById('volumeOption').value),
                        playbackRate: parseFloat(document.getElementById('playbackRateOption').value)
                    };
                    break;
                    
                case 'base64Tab':
                    type = 'base64';
                    value = document.getElementById('base64Input').value;
                    if (!value || !value.includes('base64')) {
                        alert('Masukkan data base64 yang valid');
                        return;
                    }
                    
                    // Add video options jika video base64
                    if (value.includes('data:video/')) {
                        videoOptions = {
                            autoplay: document.getElementById('autoPlayOptionGlobal').checked,
                            loop: document.getElementById('loopOptionGlobal').checked,
                            muted: document.getElementById('mutedOptionGlobal').checked
                        };
                    }
                    break;
            }
            
            formData.append('type', type);
            formData.append('value', value);
            formData.append('videoOptions', JSON.stringify(videoOptions));
            
            try {
                const res = await fetch('/api/background', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await res.json();
                
                if (data.success) {
                    currentBackground = data.background;
                    applyBackgroundToPage();
                    closeBackgroundModal();
                    alert('✅ Background berhasil diupdate!');
                } else {
                    alert('❌ Error: ' + data.error);
                }
            } catch (error) {
                alert('❌ Gagal mengupdate background');
                console.error(error);
            }
        }

        async function resetBackground() {
            if (!confirm('Reset background ke default?')) return;
            
            try {
                const res = await fetch('/api/background/reset', { method: 'POST' });
                const data = await res.json();
                
                if (data.success) {
                    currentBackground = data.background;
                    applyBackgroundToPage();
                    alert('✅ Background berhasil direset');
                }
            } catch (error) {
                alert('❌ Gagal reset background');
            }
        }

        function captureScreenshot() {
            alert('Fitur screenshot: Gunakan Print Screen atau screenshot tool lain, lalu paste ke Base64 tab');
        }

        // File Upload Drag & Drop
        function handleDragOver(e) {
            e.preventDefault();
            e.stopPropagation();
            document.getElementById('fileUploadArea').classList.add('dragover');
        }

        function handleDragLeave(e) {
            e.preventDefault();
            e.stopPropagation();
            document.getElementById('fileUploadArea').classList.remove('dragover');
        }

        function handleFileDrop(e) {
            e.preventDefault();
            e.stopPropagation();
            document.getElementById('fileUploadArea').classList.remove('dragover');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                document.getElementById('botFile').files = files;
                document.getElementById('fileName').textContent = \`File: \${files[0].name}\`;
            }
        }

        // Add Modal Functions
        const addModal = document.getElementById('addModal');
        function openAddModal() { 
            addModal.classList.add('active'); 
        }
        
        function closeAddModal() { 
            addModal.classList.remove('active'); 
            document.getElementById('addForm').reset();
            document.getElementById('fileName').textContent = '';
        }

        document.getElementById('botFile').addEventListener('change', function(e) {
            if (e.target.files.length > 0) {
                document.getElementById('fileName').textContent = \`File: \${e.target.files[0].name}\`;
            }
        });

        document.getElementById('addForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData();
            formData.append('name', document.getElementById('name').value);
            formData.append('botFile', document.getElementById('botFile').files[0]);

            try {
                const res = await fetch('/api/bots', { method: 'POST', body: formData });
                if (res.ok) {
                    const result = await res.json();
                    alert('✅ ' + (result.message || 'Bot Berhasil Ditambahkan!'));
                    closeAddModal();
                    await loadData();
                } else {
                    const err = await res.json();
                    alert('❌ Error: ' + (err.error || 'Gagal menambah bot'));
                }
            } catch (error) {
                alert('❌ Gagal menambah bot: ' + error.message);
            }
        });

        // Bot Control Functions
        async function startBot(id) {
            try {
                const res = await fetch('/api/bots/' + id + '/start', { method: 'POST' });
                const data = await res.json();
                
                if(res.ok && data.success) {
                    alert('✅ ' + data.message);
                    await loadData();
                } else {
                    alert('❌ Error: ' + (data.error || 'Gagal menjalankan bot'));
                }
            } catch (error) {
                console.error('Start bot error:', error);
                alert('❌ Gagal menjalankan bot: ' + error.message);
            }
        }

        async function stopBot(id) {
            try {
                const res = await fetch('/api/bots/' + id + '/stop', { method: 'POST' });
                const data = await res.json();
                
                if(res.ok && data.success) {
                    alert('✅ ' + data.message);
                    await loadData();
                } else {
                    alert('❌ Error: ' + (data.error || 'Gagal menghentikan bot'));
                }
            } catch (error) {
                console.error('Stop bot error:', error);
                alert('❌ Gagal menghentikan bot: ' + error.message);
            }
        }

        async function restartBot(id) {
            try {
                const res = await fetch('/api/bots/' + id + '/restart', { method: 'POST' });
                const data = await res.json();
                
                if(res.ok && data.success) {
                    alert('✅ ' + data.message);
                    await loadData();
                } else {
                    alert('❌ Error: ' + (data.error || 'Gagal restart bot'));
                }
            } catch (error) {
                console.error('Restart bot error:', error);
                alert('❌ Gagal restart bot: ' + error.message);
            }
        }

        async function deleteBot(id) {
            if(!confirm('⚠️ Yakin ingin menghapus bot ini?\\nSemua file bot akan dihapus permanen!')) return;
            
            try {
                const response = await fetch(\`/api/bots/\${id}\`, {
                    method: 'DELETE'
                });
                
                const result = await response.json();
                
                if (response.ok && result.success) {
                    alert('✅ ' + (result.message || 'Bot berhasil dihapus'));
                    
                    // Hapus card dari UI
                    const cardToRemove = document.querySelector(\`[data-bot-id="\${id}"]\`);
                    if (cardToRemove) {
                        cardToRemove.remove();
                    }
                    
                    // Refresh data
                    await loadData();
                } else {
                    alert('❌ Error: ' + (result.error || 'Gagal menghapus bot'));
                }
            } catch (error) {
                console.error('Delete bot error:', error);
                alert('❌ Gagal menghapus bot: ' + error.message);
            }
        }

        // Terminal Functions
        const termModal = document.getElementById('terminalModal');
        const termOutput = document.getElementById('terminalOutput');
        
        function openTerminal(id, name) {
            currentBotId = id;
            document.getElementById('termTitle').innerText = \`💻 Terminal: \${name || 'Bot'}\`;
            termOutput.innerHTML = \`Connected to bots/\${id}...<br>Ready.<br>\`;
            termModal.classList.add('active');
            document.getElementById('cmdInput').focus();
        }

        function closeTerminal() { 
            termModal.classList.remove('active'); 
            currentBotId = null; 
        }

        document.getElementById('cmdForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const cmd = document.getElementById('cmdInput').value;
            termOutput.innerHTML += \`<span style="color:white">root@server:$</span> \${cmd}<br>\`;
            termOutput.scrollTop = termOutput.scrollHeight;

            try {
                const res = await fetch('/api/terminal', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: currentBotId, command: cmd })
                });
                
                const data = await res.json();
                termOutput.innerHTML += (data.output || 'No output').replace(/\\n/g, '<br>') + '<br>';
                termOutput.scrollTop = termOutput.scrollHeight;
                document.getElementById('cmdInput').value = '';
            } catch (error) {
                termOutput.innerHTML += 'Error executing command<br>';
                console.error('Terminal error:', error);
            }
        });

        // Initialize
        loadData();
        
        // Auto refresh every 30 seconds
        setInterval(loadData, 30000);
    </script>
</body>
</html>`;
    res.send(htmlContent);
});

app.listen(PORT, () => {
    console.log(`🦀 Panel Inori berjalan di http://localhost:${PORT}`);
    console.log(`🎬 Background video feature aktif`);
    console.log(`📁 Video folder: ${VIDEOS_DIR}`);
    console.log(`📸 WhatsApp preview image: https://files.catbox.moe/4kpvbt.jpeg`);
});
